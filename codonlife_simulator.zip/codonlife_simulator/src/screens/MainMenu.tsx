import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

const MainMenu: React.FC = () => {
  const navigate = useNavigate();
  const { state } = useAppContext();

  const menuItems = [
    {
      id: 'new-simulation',
      title: 'New Simulation',
      icon: 'fa fa-plus',
      description: 'Start a fresh evolution experiment',
      action: () => navigate('/setup'),
      color: 'from-retro-green to-retro-blue',
    },
    {
      id: 'load-simulation',
      title: 'Load Simulation',
      icon: 'fa fa-folder-open',
      description: 'Continue previous experiments',
      action: () => navigate('/load'),
      color: 'from-retro-blue to-retro-purple',
    },
    {
      id: 'tutorial',
      title: 'Tutorial',
      icon: 'fa fa-question-circle',
      description: 'Learn the codon system',
      action: () => navigate('/tutorial'),
      color: 'from-retro-purple to-retro-pink',
    },
    {
      id: 'settings',
      title: 'Settings',
      icon: 'fa fa-cog',
      description: 'Customize your experience',
      action: () => navigate('/settings'),
      color: 'from-retro-pink to-retro-yellow',
    },
  ];

  return (
    <div className="min-h-screen safe-top safe-bottom safe-left safe-right">
      {/* Header */}
      <div className="text-center py-8 px-4">
        <div className="mb-4">
          <i className="fa fa-dna text-4xl md:text-6xl text-retro-green pulse-glow"></i>
        </div>
        <h1 className="text-2xl md:text-4xl font-bold pixel-text text-retro-green mb-2">
          CodonLife Simulator
        </h1>
        <p className="text-sm md:text-base text-retro-blue font-pixel">
          Evolution through genetic algorithms
        </p>
      </div>

      {/* Menu Items */}
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={item.action}
              className={`retro-card p-6 w-full text-left transform transition-all duration-300 hover:scale-105 hover:glow-effect active:scale-95 min-h-[120px] bg-gradient-to-br ${item.color} bg-opacity-20`}
              data-testid={item.id}
            >
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <i className={`${item.icon} text-2xl md:text-3xl text-retro-green`}></i>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg md:text-xl font-bold pixel-text text-white mb-2">
                    {item.title}
                  </h3>
                  <p className="text-sm md:text-base text-retro-yellow font-pixel leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Stats Section */}
      <div className="container mx-auto px-4 max-w-2xl mt-8">
        <div className="retro-card p-4 bg-gradient-to-r from-retro-dark to-retro-gray">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-xl md:text-2xl font-bold pixel-text text-retro-green">
                {state.savedSimulations.length}
              </div>
              <div className="text-xs md:text-sm text-retro-blue font-pixel">
                Saved Sims
              </div>
            </div>
            <div>
              <div className="text-xl md:text-2xl font-bold pixel-text text-retro-purple">
                64
              </div>
              <div className="text-xs md:text-sm text-retro-blue font-pixel">
                Codons
              </div>
            </div>
            <div className="col-span-2 md:col-span-1">
              <div className="text-xl md:text-2xl font-bold pixel-text text-retro-yellow">
                ∞
              </div>
              <div className="text-xs md:text-sm text-retro-blue font-pixel">
                Possibilities
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center mt-8 pb-8 px-4">
        <div className="flex justify-center space-x-6 text-retro-green">
          <i className="fa fa-bacteria text-lg animate-pulse"></i>
          <i className="fa fa-dna text-lg animate-spin-slow"></i>
          <i className="fa fa-microscope text-lg animate-bounce-slow"></i>
        </div>
      </div>
    </div>
  );
};

export default MainMenu;