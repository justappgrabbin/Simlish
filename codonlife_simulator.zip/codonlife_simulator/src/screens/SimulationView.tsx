import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

interface Organism {
  id: string;
  x: number;
  y: number;
  energy: number;
  generation: number;
  codon: string;
  color: string;
}

const SimulationView: React.FC = () => {
  const navigate = useNavigate();
  const { state, dispatch, saveSimulation } = useAppContext();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  
  const [organisms, setOrganisms] = useState<Organism[]>([]);
  const [generation, setGeneration] = useState(1);
  const [populationCount, setPopulationCount] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [showStats, setShowStats] = useState(true);

  // Codon colors for visualization
  const codonColors = [
    '#00ff00', '#0080ff', '#8000ff', '#ff00ff', '#ffff00', '#ff0000',
    '#00ffff', '#ff8000', '#80ff00', '#ff0080', '#8080ff', '#ff8080'
  ];

  useEffect(() => {
    if (state.currentSimulation) {
      initializeSimulation();
    } else {
      navigate('/menu');
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [state.currentSimulation]);

  useEffect(() => {
    if (isRunning) {
      animate();
    } else if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  }, [isRunning, speed]);

  const initializeSimulation = () => {
    if (!state.currentSimulation) return;

    const newOrganisms: Organism[] = [];
    const canvas = canvasRef.current;
    if (!canvas) return;

    for (let i = 0; i < state.currentSimulation.organisms; i++) {
      newOrganisms.push({
        id: `org_${i}`,
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        energy: 100,
        generation: 1,
        codon: generateRandomCodon(),
        color: codonColors[Math.floor(Math.random() * codonColors.length)],
      });
    }

    setOrganisms(newOrganisms);
    setPopulationCount(newOrganisms.length);
    setGeneration(1);
  };

  const generateRandomCodon = (): string => {
    const bases = ['A', 'T', 'G', 'C'];
    return Array.from({ length: 3 }, () => bases[Math.floor(Math.random() * 4)]).join('');
  };

  const animate = () => {
    updateSimulation();
    drawSimulation();
    
    const delay = Math.max(16, 100 / speed); // Minimum 16ms for 60fps
    setTimeout(() => {
      if (isRunning) {
        animationRef.current = requestAnimationFrame(animate);
      }
    }, delay);
  };

  const updateSimulation = () => {
    setOrganisms(prevOrganisms => {
      const canvas = canvasRef.current;
      if (!canvas) return prevOrganisms;

      return prevOrganisms.map(org => {
        // Simple movement
        const newX = org.x + (Math.random() - 0.5) * 2;
        const newY = org.y + (Math.random() - 0.5) * 2;

        // Keep organisms within bounds
        const boundedX = Math.max(5, Math.min(canvas.width - 5, newX));
        const boundedY = Math.max(5, Math.min(canvas.height - 5, newY));

        // Energy decreases over time
        const newEnergy = Math.max(0, org.energy - 0.1);

        return {
          ...org,
          x: boundedX,
          y: boundedY,
          energy: newEnergy,
        };
      }).filter(org => org.energy > 0); // Remove dead organisms
    });

    // Occasionally add new organisms (reproduction)
    if (Math.random() < 0.01 && organisms.length < 500) {
      const parent = organisms[Math.floor(Math.random() * organisms.length)];
      if (parent) {
        const newOrganism: Organism = {
          id: `org_${Date.now()}_${Math.random()}`,
          x: parent.x + (Math.random() - 0.5) * 20,
          y: parent.y + (Math.random() - 0.5) * 20,
          energy: 100,
          generation: parent.generation + (Math.random() < 0.1 ? 1 : 0),
          codon: Math.random() < (state.currentSimulation?.mutationRate || 0.1) 
            ? generateRandomCodon() 
            : parent.codon,
          color: codonColors[Math.floor(Math.random() * codonColors.length)],
        };

        setOrganisms(prev => [...prev, newOrganism]);
      }
    }

    setPopulationCount(organisms.length);
  };

  const drawSimulation = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    // Clear canvas with environment-based background
    const envColors: { [key: string]: string } = {
      primordial: '#1a1a2e',
      ocean: '#0f3460',
      volcanic: '#2d1b1b',
      arctic: '#1e2a3a',
      desert: '#3d2914',
    };

    const bgColor = envColors[state.currentSimulation?.environment || 'primordial'];
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw organisms
    organisms.forEach(org => {
      ctx.fillStyle = org.color;
      ctx.beginPath();
      ctx.arc(org.x, org.y, Math.max(2, org.energy / 20), 0, Math.PI * 2);
      ctx.fill();

      // Draw energy bar
      if (org.energy < 50) {
        ctx.fillStyle = 'rgba(255, 0, 0, 0.7)';
        ctx.fillRect(org.x - 5, org.y - 10, (org.energy / 100) * 10, 2);
      }
    });

    // Draw grid lines for reference
    ctx.strokeStyle = 'rgba(0, 255, 0, 0.1)';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvas.width; i += 50) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, canvas.height);
      ctx.stroke();
    }
    for (let i = 0; i < canvas.height; i += 50) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(canvas.width, i);
      ctx.stroke();
    }
  };

  const toggleSimulation = () => {
    setIsRunning(!isRunning);
    dispatch({ type: 'SET_SIMULATION_RUNNING', payload: !isRunning });
  };

  const handleSaveSimulation = () => {
    if (!state.currentSimulation) return;

    const updatedSimulation = {
      ...state.currentSimulation,
      generation,
      population: populationCount,
      savedAt: new Date().toISOString(),
    };

    saveSimulation(updatedSimulation);
    alert('Simulation saved successfully!');
  };

  const handleSpeedChange = (newSpeed: number) => {
    setSpeed(newSpeed);
    dispatch({ type: 'SET_SIMULATION_SPEED', payload: newSpeed });
  };

  return (
    <div className="min-h-screen safe-top safe-bottom safe-left safe-right">
      {/* Header */}
      <div className="flex items-center justify-between p-2 md:p-4 border-b-2 border-retro-green bg-retro-dark">
        <button
          onClick={() => navigate('/menu')}
          className="flex items-center space-x-2 text-retro-green hover:text-retro-blue transition-colors"
        >
          <i className="fa fa-arrow-left text-lg md:text-xl"></i>
          <span className="font-pixel text-sm md:text-base">Menu</span>
        </button>
        
        <div className="flex items-center space-x-2 md:space-x-4">
          <button
            onClick={toggleSimulation}
            className={`p-2 rounded-lg border-2 transition-all ${
              isRunning 
                ? 'border-retro-red text-retro-red hover:bg-retro-red hover:text-white'
                : 'border-retro-green text-retro-green hover:bg-retro-green hover:text-white'
            }`}
          >
            <i className={`fa ${isRunning ? 'fa-pause' : 'fa-play'} text-lg md:text-xl`}></i>
          </button>
          
          <button
            onClick={handleSaveSimulation}
            className="p-2 rounded-lg border-2 border-retro-blue text-retro-blue hover:bg-retro-blue hover:text-white transition-all"
          >
            <i className="fa fa-save text-lg md:text-xl"></i>
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row h-[calc(100vh-80px)]">
        {/* Main Simulation Canvas */}
        <div className="flex-1 relative">
          <canvas
            ref={canvasRef}
            width={800}
            height={600}
            className="w-full h-full border-2 border-retro-green bg-retro-dark"
            style={{ maxHeight: '60vh' }}
          />
          
          {/* Overlay Controls */}
          <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
            <div className="retro-card p-2 md:p-3 bg-opacity-90">
              <div className="text-xs md:text-sm font-pixel text-retro-green">
                Gen: {generation} | Pop: {populationCount}
              </div>
            </div>
            
            <button
              onClick={() => setShowStats(!showStats)}
              className="retro-card p-2 bg-opacity-90 text-retro-blue hover:text-retro-green transition-colors"
            >
              <i className="fa fa-chart-bar text-lg"></i>
            </button>
          </div>
        </div>

        {/* Side Panel */}
        <div className={`w-full lg:w-80 bg-retro-dark border-l-2 border-retro-green overflow-y-auto ${showStats ? 'block' : 'hidden lg:block'}`}>
          {/* Speed Control */}
          <div className="p-4 border-b border-retro-gray">
            <h3 className="font-bold pixel-text text-retro-green mb-3 flex items-center">
              <i className="fa fa-tachometer-alt mr-2"></i>
              Speed: {speed}x
            </h3>
            <input
              type="range"
              min="0.1"
              max="5"
              step="0.1"
              value={speed}
              onChange={(e) => handleSpeedChange(parseFloat(e.target.value))}
              className="w-full h-2 bg-retro-gray rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-xs font-pixel text-retro-blue mt-1">
              <span>0.1x</span>
              <span>2.5x</span>
              <span>5x</span>
            </div>
          </div>

          {/* Population Stats */}
          <div className="p-4 border-b border-retro-gray">
            <h3 className="font-bold pixel-text text-retro-green mb-3 flex items-center">
              <i className="fa fa-chart-bar mr-2"></i>
              Population Stats
            </h3>
            <div className="space-y-2 text-sm font-pixel">
              <div className="flex justify-between">
                <span className="text-retro-blue">Current:</span>
                <span className="text-retro-yellow">{populationCount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-retro-blue">Generation:</span>
                <span className="text-retro-yellow">{generation}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-retro-blue">Environment:</span>
                <span className="text-retro-yellow capitalize">
                  {state.currentSimulation?.environment}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-retro-blue">Mutation Rate:</span>
                <span className="text-retro-yellow">
                  {((state.currentSimulation?.mutationRate || 0) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </div>

          {/* Codon Panel */}
          <div className="p-4 border-b border-retro-gray">
            <h3 className="font-bold pixel-text text-retro-green mb-3 flex items-center">
              <i className="fa fa-dna mr-2"></i>
              Active Codons
            </h3>
            <div className="grid grid-cols-4 gap-2">
              {organisms.slice(0, 16).map((org, index) => (
                <div
                  key={org.id}
                  className="text-center p-2 rounded border border-retro-gray"
                  style={{ backgroundColor: org.color + '20' }}
                >
                  <div className="text-xs font-pixel text-white">{org.codon}</div>
                  <div className="text-xs font-pixel text-retro-blue">
                    G{org.generation}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="p-4">
            <div className="space-y-3">
              <button
                onClick={handleSaveSimulation}
                className="retro-button w-full py-2 text-sm"
              >
                <i className="fa fa-save mr-2"></i>
                Save Simulation
              </button>
              
              <button
                onClick={() => {
                  if (window.confirm('Reset simulation? This will lose current progress.')) {
                    initializeSimulation();
                    setIsRunning(false);
                  }
                }}
                className="w-full py-2 px-4 rounded-lg border-2 border-retro-yellow text-retro-yellow hover:bg-retro-yellow hover:text-retro-dark transition-all font-pixel text-sm"
              >
                <i className="fa fa-refresh mr-2"></i>
                Reset
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SimulationView;