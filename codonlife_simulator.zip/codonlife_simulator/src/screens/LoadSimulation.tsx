import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

const LoadSimulation: React.FC = () => {
  const navigate = useNavigate();
  const { state, dispatch, deleteSimulation } = useAppContext();
  const [selectedSimulation, setSelectedSimulation] = useState<string | null>(null);

  useEffect(() => {
    // Load simulations from localStorage if not already loaded
    if (state.savedSimulations.length === 0) {
      const saved = localStorage.getItem('saved_simulations');
      if (saved) {
        dispatch({ type: 'SET_SAVED_SIMULATIONS', payload: JSON.parse(saved) });
      }
    }
  }, []);

  const handleLoadSimulation = () => {
    if (!selectedSimulation) return;
    
    const simulation = state.savedSimulations.find(sim => sim.id === selectedSimulation);
    if (simulation) {
      dispatch({ type: 'SET_CURRENT_SIMULATION', payload: simulation });
      navigate('/simulation');
    }
  };

  const handleDeleteSimulation = (id: string) => {
    if (window.confirm('Are you sure you want to delete this simulation?')) {
      deleteSimulation(id);
      if (selectedSimulation === id) {
        setSelectedSimulation(null);
      }
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getEnvironmentIcon = (environment: string) => {
    const icons: { [key: string]: string } = {
      primordial: 'fa fa-flask',
      ocean: 'fa fa-water',
      volcanic: 'fa fa-fire',
      arctic: 'fa fa-snowflake',
      desert: 'fa fa-sun',
    };
    return icons[environment] || 'fa fa-globe';
  };

  return (
    <div className="min-h-screen safe-top safe-bottom safe-left safe-right">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b-2 border-retro-green">
        <button
          onClick={() => navigate('/menu')}
          className="flex items-center space-x-2 text-retro-green hover:text-retro-blue transition-colors"
        >
          <i className="fa fa-arrow-left text-xl"></i>
          <span className="font-pixel">Back</span>
        </button>
        <h1 className="text-xl md:text-2xl font-bold pixel-text text-retro-green">
          Load Simulation
        </h1>
        <div className="w-16"></div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {state.savedSimulations.length === 0 ? (
          /* Empty State */
          <div className="text-center py-12">
            <div className="mb-6">
              <i className="fa fa-folder-open text-6xl text-retro-gray"></i>
            </div>
            <h2 className="text-xl md:text-2xl font-bold pixel-text text-retro-blue mb-4">
              No Saved Simulations
            </h2>
            <p className="text-retro-yellow font-pixel mb-8">
              Start a new simulation to see it here
            </p>
            <button
              onClick={() => navigate('/setup')}
              className="retro-button"
            >
              <i className="fa fa-plus mr-2"></i>
              New Simulation
            </button>
          </div>
        ) : (
          <>
            {/* Simulations List */}
            <div className="space-y-4 mb-6">
              {state.savedSimulations.map((simulation) => (
                <div
                  key={simulation.id}
                  className={`retro-card p-4 cursor-pointer transition-all duration-200 ${
                    selectedSimulation === simulation.id
                      ? 'border-retro-green glow-effect bg-retro-green bg-opacity-10'
                      : 'hover:border-retro-blue'
                  }`}
                  onClick={() => setSelectedSimulation(simulation.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 flex-1 min-w-0">
                      <div className="flex-shrink-0">
                        <i className={`${getEnvironmentIcon(simulation.environment)} text-2xl text-retro-blue`}></i>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold pixel-text text-white text-sm md:text-base truncate">
                          {simulation.name}
                        </h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2 text-xs font-pixel">
                          <div className="text-retro-green">
                            Gen: {simulation.generation}
                          </div>
                          <div className="text-retro-purple">
                            Pop: {simulation.population}
                          </div>
                          <div className="text-retro-yellow">
                            Mut: {(simulation.mutationRate * 100).toFixed(1)}%
                          </div>
                          <div className="text-retro-blue">
                            {formatDate(simulation.savedAt)}
                          </div>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteSimulation(simulation.id);
                      }}
                      className="ml-4 p-2 text-retro-red hover:text-red-400 transition-colors"
                    >
                      <i className="fa fa-trash text-lg"></i>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col md:flex-row gap-4">
              <button
                onClick={handleLoadSimulation}
                disabled={!selectedSimulation}
                className={`retro-button flex-1 py-3 ${
                  !selectedSimulation ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                <i className="fa fa-play mr-2"></i>
                Load Selected
              </button>
              <button
                onClick={() => navigate('/setup')}
                className="retro-button flex-1 py-3 bg-gradient-to-r from-retro-green to-retro-yellow"
              >
                <i className="fa fa-plus mr-2"></i>
                New Simulation
              </button>
            </div>

            {/* Selected Simulation Details */}
            {selectedSimulation && (
              <div className="mt-6 retro-card p-4 bg-gradient-to-r from-retro-dark to-retro-gray">
                {(() => {
                  const sim = state.savedSimulations.find(s => s.id === selectedSimulation);
                  return sim ? (
                    <div>
                      <h3 className="font-bold pixel-text text-retro-yellow mb-3">
                        Simulation Details:
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm font-pixel">
                        <div className="space-y-2">
                          <div className="text-retro-blue">
                            <span className="text-retro-green">Environment:</span> {sim.environment}
                          </div>
                          <div className="text-retro-blue">
                            <span className="text-retro-green">Generation:</span> {sim.generation}
                          </div>
                          <div className="text-retro-blue">
                            <span className="text-retro-green">Population:</span> {sim.population}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="text-retro-blue">
                            <span className="text-retro-green">Mutation Rate:</span> {(sim.mutationRate * 100).toFixed(1)}%
                          </div>
                          <div className="text-retro-blue">
                            <span className="text-retro-green">Saved:</span> {formatDate(sim.savedAt)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : null;
                })()}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default LoadSimulation;