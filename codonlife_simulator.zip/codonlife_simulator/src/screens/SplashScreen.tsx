import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

const SplashScreen: React.FC = () => {
  const navigate = useNavigate();
  const { state } = useAppContext();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(() => navigate('/menu'), 500);
          return 100;
        }
        return prev + 2;
      });
    }, 50);

    return () => clearInterval(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center safe-top safe-bottom safe-left safe-right px-4">
      <div className="text-center mb-8">
        <div className="mb-6">
          <i className="fa fa-dna text-6xl md:text-8xl text-retro-green dna-animation pulse-glow"></i>
        </div>
        <h1 className="text-3xl md:text-5xl font-bold pixel-text mb-2 pulse-glow">
          CodonLife
        </h1>
        <h2 className="text-xl md:text-2xl pixel-text text-retro-blue">
          Simulator
        </h2>
        <p className="text-sm md:text-base text-retro-yellow mt-4 font-pixel">
          Life simulation across 64 codons
        </p>
      </div>

      <div className="w-full max-w-md px-4">
        <div className="bg-retro-gray rounded-lg p-2 border-2 border-retro-green glow-effect">
          <div 
            className="loading-bar h-4 rounded transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        <p className="text-center text-retro-green font-pixel text-sm mt-2">
          Loading... {progress}%
        </p>
      </div>

      <div className="mt-8 text-center">
        <div className="flex justify-center space-x-4 text-retro-purple">
          <i className="fa fa-bacteria text-2xl animate-bounce"></i>
          <i className="fa fa-dna text-2xl animate-pulse"></i>
          <i className="fa fa-microscope text-2xl animate-bounce" style={{ animationDelay: '0.5s' }}></i>
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;