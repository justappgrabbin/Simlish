import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

const Settings: React.FC = () => {
  const navigate = useNavigate();
  const { state, dispatch, saveSettings } = useAppContext();
  const [localSettings, setLocalSettings] = useState(state.settings);
  const [showSaveConfirm, setShowSaveConfirm] = useState(false);

  const handleSoundToggle = () => {
    setLocalSettings({
      ...localSettings,
      soundEnabled: !localSettings.soundEnabled,
    });
  };

  const handleGraphicsChange = (quality: 'low' | 'medium' | 'high') => {
    setLocalSettings({
      ...localSettings,
      graphicsQuality: quality,
    });
  };

  const handleSaveSettings = () => {
    dispatch({ type: 'UPDATE_SETTINGS', payload: localSettings });
    saveSettings();
    setShowSaveConfirm(true);
    setTimeout(() => {
      setShowSaveConfirm(false);
      navigate('/menu');
    }, 1500);
  };

  const resetToDefaults = () => {
    const defaultSettings = {
      soundEnabled: true,
      graphicsQuality: 'medium' as const,
    };
    setLocalSettings(defaultSettings);
  };

  const clearAllData = () => {
    if (window.confirm('This will delete all saved simulations and reset all settings. Are you sure?')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="min-h-screen safe-top safe-bottom safe-left safe-right">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b-2 border-retro-green">
        <button
          onClick={() => navigate('/menu')}
          className="flex items-center space-x-2 text-retro-green hover:text-retro-blue transition-colors"
        >
          <i className="fa fa-arrow-left text-xl"></i>
          <span className="font-pixel">Back</span>
        </button>
        <h1 className="text-xl md:text-2xl font-bold pixel-text text-retro-green">
          Settings
        </h1>
        <div className="w-16"></div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Audio Settings */}
        <div className="retro-card p-6 mb-6">
          <h2 className="text-lg md:text-xl font-bold pixel-text text-retro-green mb-4 flex items-center">
            <i className="fa fa-volume-up mr-3"></i>
            Audio
          </h2>
          <div className="flex items-center justify-between">
            <div>
              <div className="font-pixel text-white mb-1">Sound Effects</div>
              <div className="text-sm font-pixel text-retro-blue">
                Enable audio feedback and ambient sounds
              </div>
            </div>
            <button
              onClick={handleSoundToggle}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                localSettings.soundEnabled ? 'bg-retro-green' : 'bg-retro-gray'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  localSettings.soundEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Graphics Settings */}
        <div className="retro-card p-6 mb-6">
          <h2 className="text-lg md:text-xl font-bold pixel-text text-retro-green mb-4 flex items-center">
            <i className="fa fa-tv mr-3"></i>
            Graphics Quality
          </h2>
          <div className="space-y-3">
            {[
              { value: 'low', label: 'Low', description: 'Better performance, basic visuals' },
              { value: 'medium', label: 'Medium', description: 'Balanced performance and quality' },
              { value: 'high', label: 'High', description: 'Best visuals, may impact performance' },
            ].map((option) => (
              <button
                key={option.value}
                onClick={() => handleGraphicsChange(option.value as 'low' | 'medium' | 'high')}
                className={`w-full p-4 rounded-lg border-2 text-left transition-all ${
                  localSettings.graphicsQuality === option.value
                    ? 'border-retro-green bg-retro-green bg-opacity-20 glow-effect'
                    : 'border-retro-gray hover:border-retro-blue'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-pixel text-white mb-1">{option.label}</div>
                    <div className="text-sm font-pixel text-retro-blue">
                      {option.description}
                    </div>
                  </div>
                  <div className={`w-4 h-4 rounded-full border-2 ${
                    localSettings.graphicsQuality === option.value
                      ? 'border-retro-green bg-retro-green'
                      : 'border-retro-gray'
                  }`} />
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Data Management */}
        <div className="retro-card p-6 mb-6">
          <h2 className="text-lg md:text-xl font-bold pixel-text text-retro-green mb-4 flex items-center">
            <i className="fa fa-database mr-3"></i>
            Data Management
          </h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-pixel text-white mb-1">Saved Simulations</div>
                <div className="text-sm font-pixel text-retro-blue">
                  {state.savedSimulations.length} simulations stored locally
                </div>
              </div>
              <div className="text-retro-green font-pixel">
                {(JSON.stringify(state.savedSimulations).length / 1024).toFixed(1)} KB
              </div>
            </div>
            <button
              onClick={clearAllData}
              className="w-full p-3 rounded-lg border-2 border-retro-red text-retro-red hover:bg-retro-red hover:text-white transition-all font-pixel"
            >
              <i className="fa fa-trash mr-2"></i>
              Clear All Data
            </button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <button
            onClick={resetToDefaults}
            className="flex-1 p-3 rounded-lg border-2 border-retro-yellow text-retro-yellow hover:bg-retro-yellow hover:text-retro-dark transition-all font-pixel"
          >
            <i className="fa fa-undo mr-2"></i>
            Reset to Defaults
          </button>
          <button
            onClick={handleSaveSettings}
            className="retro-button flex-1 py-3"
            disabled={showSaveConfirm}
          >
            {showSaveConfirm ? (
              <>
                <i className="fa fa-check mr-2"></i>
                Saved!
              </>
            ) : (
              <>
                <i className="fa fa-save mr-2"></i>
                Save Settings
              </>
            )}
          </button>
        </div>

        {/* App Info */}
        <div className="retro-card p-4 bg-gradient-to-r from-retro-dark to-retro-gray">
          <div className="text-center">
            <div className="mb-2">
              <i className="fa fa-dna text-2xl text-retro-green"></i>
            </div>
            <div className="font-pixel text-retro-green text-lg mb-1">CodonLife Simulator</div>
            <div className="font-pixel text-retro-blue text-sm mb-2">Version 1.0.0</div>
            <div className="font-pixel text-retro-yellow text-xs">
              Simulating evolution through genetic algorithms
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;