import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface TutorialStep {
  id: number;
  title: string;
  content: string;
  icon: string;
  visual: string;
}

const Tutorial: React.FC = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);

  const tutorialSteps: TutorialStep[] = [
    {
      id: 1,
      title: 'Welcome to CodonLife',
      content: 'CodonLife simulates evolution through genetic algorithms. Watch as digital organisms evolve and adapt using the 64-codon genetic code system.',
      icon: 'fa fa-dna',
      visual: '🧬',
    },
    {
      id: 2,
      title: 'The Genetic Code',
      content: 'Each organism has a genetic code made of codons - triplets of nucleotides. There are 64 possible codons that determine organism traits and behaviors.',
      icon: 'fa fa-code',
      visual: 'ATG→CGC→TAA',
    },
    {
      id: 3,
      title: 'Evolution Process',
      content: 'Organisms reproduce, mutate, and compete for resources. Successful traits spread through the population over generations.',
      icon: 'fa fa-random',
      visual: '🦠→🦠🦠→🦠🦠🦠',
    },
    {
      id: 4,
      title: 'Environment Effects',
      content: 'Different environments favor different traits. Volcanic vents reward heat resistance, while arctic conditions favor cold adaptation.',
      icon: 'fa fa-globe',
      visual: '🌋❄️🏜️🌊',
    },
    {
      id: 5,
      title: 'Simulation Controls',
      content: 'Use speed controls to accelerate evolution, monitor population statistics, and save interesting simulations for later study.',
      icon: 'fa fa-play-circle',
      visual: '⏯️📊💾',
    },
    {
      id: 6,
      title: 'Ready to Evolve!',
      content: 'You\'re ready to start your first simulation! Experiment with different settings and watch life find a way.',
      icon: 'fa fa-rocket',
      visual: '🚀',
    },
  ];

  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      navigate('/menu');
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const skipTutorial = () => {
    navigate('/menu');
  };

  const currentTutorial = tutorialSteps[currentStep];

  return (
    <div className="min-h-screen safe-top safe-bottom safe-left safe-right">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b-2 border-retro-green">
        <button
          onClick={() => navigate('/menu')}
          className="flex items-center space-x-2 text-retro-green hover:text-retro-blue transition-colors"
        >
          <i className="fa fa-arrow-left text-xl"></i>
          <span className="font-pixel">Back</span>
        </button>
        <h1 className="text-xl md:text-2xl font-bold pixel-text text-retro-green">
          Tutorial
        </h1>
        <button
          onClick={skipTutorial}
          className="text-retro-yellow hover:text-retro-red transition-colors font-pixel text-sm"
        >
          Skip
        </button>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-pixel text-retro-blue">
              Step {currentStep + 1} of {tutorialSteps.length}
            </span>
            <span className="text-sm font-pixel text-retro-blue">
              {Math.round(((currentStep + 1) / tutorialSteps.length) * 100)}%
            </span>
          </div>
          <div className="bg-retro-gray rounded-lg h-2 border border-retro-green">
            <div
              className="loading-bar h-full rounded transition-all duration-300"
              style={{ width: `${((currentStep + 1) / tutorialSteps.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Tutorial Content */}
        <div className="retro-card p-6 md:p-8 mb-8 min-h-[400px] flex flex-col justify-center">
          <div className="text-center mb-6">
            <div className="mb-4">
              <i className={`${currentTutorial.icon} text-4xl md:text-6xl text-retro-green pulse-glow`}></i>
            </div>
            <div className="text-4xl md:text-6xl mb-4">
              {currentTutorial.visual}
            </div>
          </div>

          <h2 className="text-xl md:text-2xl font-bold pixel-text text-retro-green mb-4 text-center">
            {currentTutorial.title}
          </h2>

          <p className="text-sm md:text-base font-pixel text-retro-blue leading-relaxed text-center">
            {currentTutorial.content}
          </p>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <button
            onClick={prevStep}
            disabled={currentStep === 0}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg border-2 transition-all ${
              currentStep === 0
                ? 'border-retro-gray text-retro-gray cursor-not-allowed'
                : 'border-retro-blue text-retro-blue hover:bg-retro-blue hover:text-white'
            }`}
          >
            <i className="fa fa-chevron-left"></i>
            <span className="font-pixel">Previous</span>
          </button>

          {/* Step Indicators */}
          <div className="flex space-x-2">
            {tutorialSteps.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentStep(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentStep
                    ? 'bg-retro-green glow-effect'
                    : index < currentStep
                    ? 'bg-retro-blue'
                    : 'bg-retro-gray'
                }`}
              />
            ))}
          </div>

          <button
            onClick={nextStep}
            className="retro-button px-4 py-2 flex items-center space-x-2"
          >
            <span className="font-pixel">
              {currentStep === tutorialSteps.length - 1 ? 'Start' : 'Next'}
            </span>
            <i className={`fa ${currentStep === tutorialSteps.length - 1 ? 'fa-rocket' : 'fa-chevron-right'}`}></i>
          </button>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={() => navigate('/setup')}
            className="retro-card p-4 hover:glow-effect transition-all text-center"
          >
            <i className="fa fa-plus text-2xl text-retro-green mb-2"></i>
            <div className="font-pixel text-white text-sm">Start New Simulation</div>
          </button>
          <button
            onClick={() => navigate('/load')}
            className="retro-card p-4 hover:glow-effect transition-all text-center"
          >
            <i className="fa fa-folder-open text-2xl text-retro-blue mb-2"></i>
            <div className="font-pixel text-white text-sm">Load Saved Simulation</div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Tutorial;