import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

interface SimulationConfig {
  environment: string;
  organisms: number;
  mutationRate: number;
}

const SimulationSetup: React.FC = () => {
  const navigate = useNavigate();
  const { dispatch } = useAppContext();
  
  const [config, setConfig] = useState<SimulationConfig>({
    environment: 'primordial',
    organisms: 100,
    mutationRate: 0.1,
  });

  const environments = [
    { value: 'primordial', label: 'Primordial Soup', icon: 'fa fa-flask' },
    { value: 'ocean', label: 'Deep Ocean', icon: 'fa fa-water' },
    { value: 'volcanic', label: 'Volcanic Vents', icon: 'fa fa-fire' },
    { value: 'arctic', label: 'Arctic Tundra', icon: 'fa fa-snowflake' },
    { value: 'desert', label: 'Desert Oasis', icon: 'fa fa-sun' },
  ];

  const handleStartSimulation = () => {
    const newSimulation = {
      id: Date.now().toString(),
      name: `${environments.find(e => e.value === config.environment)?.label} - ${new Date().toLocaleDateString()}`,
      environment: config.environment,
      organisms: config.organisms,
      mutationRate: config.mutationRate,
      generation: 1,
      population: config.organisms,
      savedAt: new Date().toISOString(),
    };

    dispatch({ type: 'SET_CURRENT_SIMULATION', payload: newSimulation });
    navigate('/simulation');
  };

  return (
    <div className="min-h-screen safe-top safe-bottom safe-left safe-right">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b-2 border-retro-green">
        <button
          onClick={() => navigate('/menu')}
          className="flex items-center space-x-2 text-retro-green hover:text-retro-blue transition-colors"
        >
          <i className="fa fa-arrow-left text-xl"></i>
          <span className="font-pixel">Back</span>
        </button>
        <h1 className="text-xl md:text-2xl font-bold pixel-text text-retro-green">
          Simulation Setup
        </h1>
        <div className="w-16"></div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Environment Selection */}
        <div className="retro-card p-6 mb-6">
          <h2 className="text-lg md:text-xl font-bold pixel-text text-retro-green mb-4 flex items-center">
            <i className="fa fa-globe mr-3"></i>
            Environment
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {environments.map((env) => (
              <button
                key={env.value}
                onClick={() => setConfig({ ...config, environment: env.value })}
                className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                  config.environment === env.value
                    ? 'border-retro-green bg-retro-green bg-opacity-20 glow-effect'
                    : 'border-retro-gray hover:border-retro-blue'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <i className={`${env.icon} text-xl text-retro-blue`}></i>
                  <span className="font-pixel text-white text-sm md:text-base">
                    {env.label}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Starting Organisms */}
        <div className="retro-card p-6 mb-6">
          <h2 className="text-lg md:text-xl font-bold pixel-text text-retro-green mb-4 flex items-center">
            <i className="fa fa-bacteria mr-3"></i>
            Starting Organisms: {config.organisms}
          </h2>
          <div className="space-y-4">
            <input
              type="range"
              min="10"
              max="1000"
              step="10"
              value={config.organisms}
              onChange={(e) => setConfig({ ...config, organisms: parseInt(e.target.value) })}
              className="w-full h-3 bg-retro-gray rounded-lg appearance-none cursor-pointer slider"
            />
            <div className="flex justify-between text-xs font-pixel text-retro-blue">
              <span>10</span>
              <span>500</span>
              <span>1000</span>
            </div>
          </div>
        </div>

        {/* Mutation Rate */}
        <div className="retro-card p-6 mb-8">
          <h2 className="text-lg md:text-xl font-bold pixel-text text-retro-green mb-4 flex items-center">
            <i className="fa fa-random mr-3"></i>
            Mutation Rate: {(config.mutationRate * 100).toFixed(1)}%
          </h2>
          <div className="space-y-4">
            <input
              type="range"
              min="0.01"
              max="0.5"
              step="0.01"
              value={config.mutationRate}
              onChange={(e) => setConfig({ ...config, mutationRate: parseFloat(e.target.value) })}
              className="w-full h-3 bg-retro-gray rounded-lg appearance-none cursor-pointer slider"
            />
            <div className="flex justify-between text-xs font-pixel text-retro-blue">
              <span>1%</span>
              <span>25%</span>
              <span>50%</span>
            </div>
          </div>
        </div>

        {/* Start Button */}
        <button
          onClick={handleStartSimulation}
          className="retro-button w-full text-lg md:text-xl py-4 flex items-center justify-center space-x-3"
        >
          <i className="fa fa-play text-xl"></i>
          <span>Start Simulation</span>
        </button>

        {/* Preview Info */}
        <div className="mt-6 retro-card p-4 bg-gradient-to-r from-retro-dark to-retro-gray">
          <h3 className="font-bold pixel-text text-retro-yellow mb-2">Preview:</h3>
          <div className="text-sm font-pixel text-retro-blue space-y-1">
            <p>Environment: {environments.find(e => e.value === config.environment)?.label}</p>
            <p>Initial Population: {config.organisms} organisms</p>
            <p>Mutation Rate: {(config.mutationRate * 100).toFixed(1)}% per generation</p>
            <p>Expected Runtime: ~{Math.ceil(config.organisms / 100)} minutes</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SimulationSetup;