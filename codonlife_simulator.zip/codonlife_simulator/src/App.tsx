import BrandingBadge from './components/BrandingBadge';
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import SplashScreen from './screens/SplashScreen';
import MainMenu from './screens/MainMenu';
import SimulationSetup from './screens/SimulationSetup';
import LoadSimulation from './screens/LoadSimulation';
import Tutorial from './screens/Tutorial';
import Settings from './screens/Settings';
import SimulationView from './screens/SimulationView';

const App: React.FC = () => {
  return (
    <AppProvider>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-retro-dark to-retro-gray">
          <Routes>
            <Route path="/" element={<SplashScreen />} />
            <Route path="/menu" element={<MainMenu />} />
            <Route path="/setup" element={<SimulationSetup />} />
            <Route path="/load" element={<LoadSimulation />} />
            <Route path="/tutorial" element={<Tutorial />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/simulation" element={<SimulationView />} />
            <Route path="*" element={<MainMenu />} />
          </Routes>
          <BrandingBadge />
</div>
      </Router>
    </AppProvider>
  );
};

export default App;