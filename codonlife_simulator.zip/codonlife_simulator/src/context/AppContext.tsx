import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { apiService } from '../services/apiService';

interface User {
  id: string;
  provider: string;
  created_at: string;
}

interface SimulationData {
  id: string;
  name: string;
  environment: string;
  organisms: number;
  mutationRate: number;
  generation: number;
  population: number;
  savedAt: string;
}

interface Settings {
  soundEnabled: boolean;
  graphicsQuality: 'low' | 'medium' | 'high';
}

interface AppState {
  user: User | null;
  isLoading: boolean;
  currentSimulation: SimulationData | null;
  savedSimulations: SimulationData[];
  settings: Settings;
  isSimulationRunning: boolean;
  simulationSpeed: number;
}

type AppAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_USER'; payload: User }
  | { type: 'SET_CURRENT_SIMULATION'; payload: SimulationData | null }
  | { type: 'ADD_SAVED_SIMULATION'; payload: SimulationData }
  | { type: 'REMOVE_SAVED_SIMULATION'; payload: string }
  | { type: 'SET_SAVED_SIMULATIONS'; payload: SimulationData[] }
  | { type: 'UPDATE_SETTINGS'; payload: Partial<Settings> }
  | { type: 'SET_SIMULATION_RUNNING'; payload: boolean }
  | { type: 'SET_SIMULATION_SPEED'; payload: number };

const initialState: AppState = {
  user: null,
  isLoading: false,
  currentSimulation: null,
  savedSimulations: [],
  settings: {
    soundEnabled: true,
    graphicsQuality: 'medium',
  },
  isSimulationRunning: false,
  simulationSpeed: 1,
};

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'SET_CURRENT_SIMULATION':
      return { ...state, currentSimulation: action.payload };
    case 'ADD_SAVED_SIMULATION':
      return {
        ...state,
        savedSimulations: [...state.savedSimulations, action.payload],
      };
    case 'REMOVE_SAVED_SIMULATION':
      return {
        ...state,
        savedSimulations: state.savedSimulations.filter(sim => sim.id !== action.payload),
      };
    case 'SET_SAVED_SIMULATIONS':
      return { ...state, savedSimulations: action.payload };
    case 'UPDATE_SETTINGS':
      return {
        ...state,
        settings: { ...state.settings, ...action.payload },
      };
    case 'SET_SIMULATION_RUNNING':
      return { ...state, isSimulationRunning: action.payload };
    case 'SET_SIMULATION_SPEED':
      return { ...state, simulationSpeed: action.payload };
    default:
      return state;
  }
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  createAnonymousUser: () => Promise<void>;
  saveSimulation: (simulation: SimulationData) => void;
  loadSavedSimulations: () => void;
  deleteSimulation: (id: string) => void;
  saveSettings: () => void;
} | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  useEffect(() => {
    // Load saved data from localStorage
    const savedUser = localStorage.getItem('user_data');
    const savedSimulations = localStorage.getItem('saved_simulations');
    const savedSettings = localStorage.getItem('app_settings');

    if (savedUser) {
      dispatch({ type: 'SET_USER', payload: JSON.parse(savedUser) });
    }

    if (savedSimulations) {
      dispatch({ type: 'SET_SAVED_SIMULATIONS', payload: JSON.parse(savedSimulations) });
    }

    if (savedSettings) {
      dispatch({ type: 'UPDATE_SETTINGS', payload: JSON.parse(savedSettings) });
    }

    // Create anonymous user if none exists
    if (!savedUser) {
      createAnonymousUser();
    }
  }, []);

  const createAnonymousUser = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      const response = await apiService.createUser();
      dispatch({ type: 'SET_USER', payload: response });
      localStorage.setItem('user_data', JSON.stringify(response));
    } catch (error) {
      console.error('Failed to create anonymous user:', error);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const saveSimulation = (simulation: SimulationData) => {
    dispatch({ type: 'ADD_SAVED_SIMULATION', payload: simulation });
    const updatedSimulations = [...state.savedSimulations, simulation];
    localStorage.setItem('saved_simulations', JSON.stringify(updatedSimulations));
  };

  const loadSavedSimulations = () => {
    const saved = localStorage.getItem('saved_simulations');
    if (saved) {
      dispatch({ type: 'SET_SAVED_SIMULATIONS', payload: JSON.parse(saved) });
    }
  };

  const deleteSimulation = (id: string) => {
    dispatch({ type: 'REMOVE_SAVED_SIMULATION', payload: id });
    const updatedSimulations = state.savedSimulations.filter(sim => sim.id !== id);
    localStorage.setItem('saved_simulations', JSON.stringify(updatedSimulations));
  };

  const saveSettings = () => {
    localStorage.setItem('app_settings', JSON.stringify(state.settings));
  };

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        createAnonymousUser,
        saveSimulation,
        loadSavedSimulations,
        deleteSimulation,
        saveSettings,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};