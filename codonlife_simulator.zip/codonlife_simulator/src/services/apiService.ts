const BASE_URL = import.meta.env.DEV ? '/api' : 'https://alexis5j5cbr.lastapp.dev';
const APP_ID = '5ac6b2f4-c2de-4d72-8d1e-be665262abf6';

interface User {
  id: string;
  provider: string;
  created_at: string;
}

interface ApiResponse<T> {
  data?: T;
  error?: string;
}

class ApiService {
  private async makeRequest<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  async createUser(): Promise<User> {
    const payload = {
      app_id: APP_ID,
      table_name: 'users',
      data: {
        provider: 'anonymous',
      },
    };

    return this.makeRequest<User>('/data', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  // Additional API methods can be added here as needed
  async saveUserData(userId: string, data: any): Promise<any> {
    const payload = {
      app_id: APP_ID,
      table_name: 'user_data',
      data: {
        user_id: userId,
        ...data,
      },
    };

    return this.makeRequest<any>('/data', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  async getUserData(userId: string): Promise<any> {
    return this.makeRequest<any>(`/data?app_id=${APP_ID}&table_name=user_data&user_id=${userId}`);
  }
}

export const apiService = new ApiService();