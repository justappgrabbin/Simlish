/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'retro-green': '#00ff00',
        'retro-blue': '#0080ff',
        'retro-purple': '#8000ff',
        'retro-pink': '#ff00ff',
        'retro-yellow': '#ffff00',
        'retro-red': '#ff0000',
        'retro-dark': '#1a1a1a',
        'retro-gray': '#333333',
      },
      fontFamily: {
        'pixel': ['Courier New', 'monospace'],
      },
      animation: {
        'pulse-slow': 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'bounce-slow': 'bounce 2s infinite',
        'spin-slow': 'spin 3s linear infinite',
      },
      backdropBlur: {
        xs: '2px',
      },
    },
  },
  plugins: [],
}