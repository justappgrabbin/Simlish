"""
Phase 2 Examples - Neural Network & API Integration

Demonstrates:
1. Graph building from HD charts
2. Neural network processing
3. Awareness analysis
4. API usage
5. Complete integration
"""

import sys
sys.path.append('python_engine')

import torch
import numpy as np
from neural.graph_builder import GraphBuilder, HDChart
from neural.hd_network import HDNetwork
from neural.awareness_pooler import AwarenessPooler, AwarenessVisualizer

def example_1_graph_builder():
    """Example 1: Build graph from HD chart"""
    print("\n" + "="*60)
    print("EXAMPLE 1: GRAPH BUILDER")
    print("="*60)
    
    # Create example chart
    chart = HDChart(
        type="Generator",
        strategy="To Respond",
        authority="Sacral",
        profile="4/6",
        defined_centers=["sacral", "throat", "g"],
        undefined_centers=["head", "ajna", "heart", "spleen", "solar_plexus", "root"],
        gates={
            20: {"line": 3, "activation": "personality", "center": "throat"},
            34: {"line": 5, "activation": "personality", "center": "sacral"},
            57: {"line": 1, "activation": "design", "center": "spleen"},
            10: {"line": 2, "activation": "design", "center": "g"}
        },
        channels=[
            {"gate_a": 20, "gate_b": 34, "name": "Charisma"},
            {"gate_a": 10, "gate_b": 57, "name": "Survival"}
        ]
    )
    
    # Build graph
    builder = GraphBuilder()
    graph = builder.build_graph(chart)
    
    print(f"\nChart Type: {chart.type}")
    print(f"Profile: {chart.profile}")
    print(f"\nGraph Structure:")
    print(f"  Node features: {graph['node_features'].shape}")
    print(f"  Edge index: {graph['edge_index'].shape}")
    print(f"  Channels: {graph['edge_index'].shape[1] // 2}")
    
    print(f"\nAwareness Masks:")
    for name, mask in graph['awareness_masks'].items():
        print(f"  {name}: {mask.sum()} gates active")

def example_2_neural_network():
    """Example 2: Run neural network"""
    print("\n" + "="*60)
    print("EXAMPLE 2: NEURAL NETWORK")
    print("="*60)
    
    # Create model
    model = HDNetwork(input_dim=19, hidden_dim=64)
    
    # Create dummy inputs
    node_features = torch.randn(64, 19)
    edge_index = torch.randint(0, 64, (2, 100))
    
    awareness_masks = {
        'spleen': torch.zeros(64, dtype=torch.bool),
        'ajna': torch.zeros(64, dtype=torch.bool),
        'solar_plexus': torch.zeros(64, dtype=torch.bool),
        'heart': torch.zeros(64, dtype=torch.bool)
    }
    
    # Activate some gates
    awareness_masks['spleen'][[56, 43, 49]] = True
    awareness_masks['ajna'][[46, 23, 3]] = True
    
    # Sun position
    sun_encoding = model.encode_sun_position(25, 3)
    
    # Forward pass
    output = model(node_features, edge_index, awareness_masks, sun_encoding)
    
    print(f"\nModel Output:")
    print(f"  Codon scores: {output['codon_scores'].shape}")
    print(f"  Spleen awareness: {output['spleen_awareness'].shape}")
    print(f"  Heart readout: {output['heart'].shape}")
    print(f"  Mind readout: {output['mind'].shape}")
    
    print(f"\nTop 5 Activated Gates:")
    top_gates = torch.argsort(output['codon_scores'], descending=True)[:5] + 1
    for i, gate in enumerate(top_gates):
        score = output['codon_scores'][gate-1]
        print(f"  {i+1}. Gate {gate.item()}: {score:.3f}")

def example_3_awareness_analysis():
    """Example 3: Awareness pooling and analysis"""
    print("\n" + "="*60)
    print("EXAMPLE 3: AWARENESS ANALYSIS")
    print("="*60)
    
    # Simulate network output
    network_output = {
        'spleen_awareness': torch.randn(64) * 2,  # Strong spleen
        'ajna_awareness': torch.randn(64),
        'solar_awareness': torch.randn(64) * 0.5,  # Weak solar
        'heart': torch.randn(64),
        'mind': torch.randn(64),
        'codon_scores': torch.rand(64)
    }
    
    # Analyze
    pooler = AwarenessPooler()
    analysis = pooler.analyze_awareness(network_output, network_output['codon_scores'])
    
    # Interpret
    interpretation = pooler.interpret_awareness(analysis)
    print(interpretation)
    
    # Visualize
    viz = AwarenessVisualizer.visualize_analysis(analysis)
    print(viz)

def example_4_complete_pipeline():
    """Example 4: Complete integrated pipeline"""
    print("\n" + "="*60)
    print("EXAMPLE 4: COMPLETE PIPELINE")
    print("="*60)
    
    print("\n🌌 Running complete consciousness computation...\n")
    
    # 1. Create chart
    print("1️⃣  Building HD Chart")
    chart = HDChart(
        type="Projector",
        strategy="Wait for Invitation",
        authority="Splenic",
        profile="3/5",
        defined_centers=["spleen", "g"],
        undefined_centers=["head", "ajna", "throat", "heart", "sacral", "solar_plexus", "root"],
        gates={
            57: {"line": 4, "activation": "personality", "center": "spleen"},
            10: {"line": 3, "activation": "design", "center": "g"},
            25: {"line": 2, "activation": "personality", "center": "g"}
        },
        channels=[
            {"gate_a": 10, "gate_b": 57, "name": "Survival"}
        ]
    )
    print(f"   ✓ Chart type: {chart.type}")
    print(f"   ✓ Profile: {chart.profile}")
    
    # 2. Build graph
    print("\n2️⃣  Building Graph")
    builder = GraphBuilder()
    graph = builder.build_graph(chart)
    graph_torch = builder.to_torch(graph)
    print(f"   ✓ Nodes: 64")
    print(f"   ✓ Edges: {graph_torch['edge_index'].shape[1]}")
    
    # 3. Create model and process
    print("\n3️⃣  Neural Network Processing")
    model = HDNetwork(input_dim=19, hidden_dim=64)
    sun_encoding = model.encode_sun_position(57, 4)  # Sun in Gate 57 Line 4
    
    with torch.no_grad():
        output = model(
            graph_torch['node_features'],
            graph_torch['edge_index'],
            graph_torch['awareness_masks'],
            sun_encoding
        )
    print(f"   ✓ Codon scores computed")
    print(f"   ✓ Awareness fields generated")
    
    # 4. Analyze awareness
    print("\n4️⃣  Awareness Analysis")
    pooler = AwarenessPooler()
    analysis = pooler.analyze_awareness(output, output['codon_scores'])
    
    print(f"   ✓ Dominant: {analysis.dominant_awareness}")
    print(f"   ✓ Spleen: {analysis.spleen_score:.3f}")
    print(f"   ✓ Ajna: {analysis.ajna_score:.3f}")
    print(f"   ✓ Solar: {analysis.solar_score:.3f}")
    print(f"   ✓ Coherence: {analysis.coherence:.3f}")
    
    # 5. Top gates
    print("\n5️⃣  Top Activated Gates")
    top_gates = torch.argsort(output['codon_scores'], descending=True)[:10]
    for i, gate in enumerate(top_gates[:5]):
        print(f"   {i+1}. Gate {gate.item()+1}: {output['codon_scores'][gate]:.3f}")
    
    # 6. Visualization
    print("\n6️⃣  Visualization")
    viz = AwarenessVisualizer.visualize_analysis(analysis)
    print(viz)
    
    print("\n✅ Complete pipeline executed successfully!")

def example_5_api_client():
    """Example 5: API client usage"""
    print("\n" + "="*60)
    print("EXAMPLE 5: API CLIENT (requires server running)")
    print("="*60)
    
    print("\nTo test API:")
    print("1. Start server: python python_engine/api/engine_api.py")
    print("2. Visit: http://localhost:8000/docs")
    print("3. Test endpoints:")
    print("   - POST /process_gates")
    print("   - POST /analyze_chart")
    print("   - POST /process_sentence")
    print("   - POST /full_pipeline")
    
    print("\nExample curl command:")
    print("""
    curl -X POST http://localhost:8000/analyze_chart \\
      -H "Content-Type: application/json" \\
      -d '{
        "type": "Generator",
        "strategy": "To Respond",
        "authority": "Sacral",
        "profile": "4/6",
        "defined_centers": ["sacral", "throat"],
        "gates": {
          "20": {"line": 3, "activation": "personality", "center": "throat"},
          "34": {"line": 5, "activation": "personality", "center": "sacral"}
        },
        "channels": [{"gate_a": 20, "gate_b": 34, "name": "Charisma"}],
        "sun_gate": 25,
        "sun_line": 3
      }'
    """)

if __name__ == "__main__":
    print("\n" + "🧠"*30)
    print("YOU-N-I-VERSE PHASE 2 - NEURAL INTEGRATION EXAMPLES")
    print("🧠"*30)
    
    example_1_graph_builder()
    example_2_neural_network()
    example_3_awareness_analysis()
    example_4_complete_pipeline()
    example_5_api_client()
    
    print("\n" + "="*60)
    print("ALL PHASE 2 EXAMPLES COMPLETED")
    print("="*60 + "\n")
