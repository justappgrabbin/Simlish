"""
Graph Builder - HD Chart to 64-Node Graph Converter

Converts Human Design charts into graph structures for GNN processing:
- 64 nodes (gates)
- Edges (channels connecting gates)
- Node features (placements, lines, definitions)
- Awareness masks (Spleen, Ajna, Solar Plexus groupings)
"""

import numpy as np
import torch
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass

@dataclass
class HDChart:
    """Human Design chart data"""
    type: str  # Generator, Projector, Manifestor, Reflector
    strategy: str
    authority: str
    profile: str
    defined_centers: List[str]
    undefined_centers: List[str]
    gates: Dict[int, Dict]  # {gate_num: {line, activation, center}}
    channels: List[Dict]  # [{gate_a, gate_b, name}]

# Channel definitions (connects which gates)
CHANNELS = [
    # Format: (gate_a, gate_b, channel_name)
    (1, 8, "Inspiration"),
    (2, 14, "The Beat"),
    (3, 60, "Mutation"),
    (4, 63, "Logic"),
    (5, 15, "Rhythm"),
    (6, 59, "Intimacy"),
    (7, 31, "The Alpha"),
    (9, 52, "Concentration"),
    (10, 20, "Awakening"),
    (10, 34, "Exploration"),
    (10, 57, "Survival"),
    (11, 56, "Curiosity"),
    (12, 22, "Openness"),
    (13, 33, "The Prodigal"),
    (16, 48, "Wavelength"),
    (17, 62, "Acceptance"),
    (18, 58, "Judgment"),
    (19, 49, "Synthesis"),
    (20, 34, "Charisma"),
    (20, 57, "Brainwave"),
    (21, 45, "Money Line"),
    (23, 43, "Structuring"),
    (24, 61, "Awareness"),
    (25, 51, "Initiation"),
    (26, 44, "Surrender"),
    (27, 50, "Preservation"),
    (28, 38, "Struggle"),
    (29, 46, "Discovery"),
    (30, 41, "Recognition"),
    (32, 54, "Transformation"),
    (35, 36, "Transitoriness"),
    (37, 40, "Community"),
    (39, 55, "Emoting"),
    (42, 53, "Maturation"),
    (47, 64, "Abstraction"),
]

# Center to gates mapping
CENTER_GATES = {
    "head": [64, 61, 63],
    "ajna": [47, 24, 4, 17, 11, 43],
    "throat": [62, 23, 56, 35, 12, 45, 33, 8, 31, 20, 16],
    "g": [1, 2, 7, 10, 13, 15, 25, 46],
    "heart": [21, 51, 26, 40],
    "sacral": [5, 14, 29, 59, 9, 3, 42, 53, 60, 52, 34],
    "spleen": [57, 44, 50, 32, 28, 18, 48],
    "solar_plexus": [55, 49, 37, 22, 30, 36, 6],
    "root": [52, 53, 54, 58, 38, 39, 41, 19, 60]
}

# Awareness groupings
AWARENESS_GATES = {
    "spleen": {57, 44, 50, 32, 28, 18},
    "ajna": {47, 24, 4, 17, 11, 43},
    "solar_plexus": {55, 49, 37, 22, 30, 36, 6}
}

HEART_GATES = {21, 51, 26, 40}

class GraphBuilder:
    """Build 64-node graphs from HD charts"""
    
    def __init__(self):
        self.channels = CHANNELS
        self.center_gates = CENTER_GATES
        self.awareness_gates = AWARENESS_GATES
        
    def build_graph(self, chart: HDChart) -> Dict:
        """Convert HD chart to graph structure"""
        
        # Build node features (64 nodes)
        node_features = self._build_node_features(chart)
        
        # Build edge index (channel connections)
        edge_index = self._build_edge_index()
        
        # Build awareness masks
        awareness_masks = self._build_awareness_masks()
        
        return {
            "node_features": node_features,  # [64, feature_dim]
            "edge_index": edge_index,        # [2, num_edges]
            "awareness_masks": awareness_masks,
            "chart": chart
        }
    
    def _build_node_features(self, chart: HDChart) -> np.ndarray:
        """Build feature vector for each of 64 gates"""
        
        features = []
        
        for gate_num in range(1, 65):
            # Initialize feature vector
            gate_features = []
            
            # 1. Placement features (body vs design)
            has_body = False
            has_design = False
            line = 0
            
            if gate_num in chart.gates:
                gate_data = chart.gates[gate_num]
                if gate_data['activation'] == 'personality':
                    has_body = True
                else:
                    has_design = True
                line = gate_data['line']
            
            gate_features.extend([
                float(has_body),
                float(has_design)
            ])
            
            # 2. Line encoding (1-6)
            line_onehot = [0.0] * 6
            if line > 0:
                line_onehot[line - 1] = 1.0
            gate_features.extend(line_onehot)
            
            # 3. Definition flags
            defined_by_placement = float(gate_num in chart.gates)
            
            # Check channel definition
            defined_by_channel = 0.0
            for channel in chart.channels:
                if channel['gate_a'] == gate_num or channel['gate_b'] == gate_num:
                    # Check if both ends are activated
                    other_gate = channel['gate_b'] if channel['gate_a'] == gate_num else channel['gate_a']
                    if other_gate in chart.gates:
                        defined_by_channel = 1.0
                        break
            
            gate_features.extend([
                defined_by_placement,
                defined_by_channel
            ])
            
            # 4. Center encoding
            gate_center = self._get_gate_center(gate_num)
            center_onehot = self._encode_center(gate_center)
            gate_features.extend(center_onehot)
            
            features.append(gate_features)
        
        return np.array(features, dtype=np.float32)  # [64, feature_dim]
    
    def _build_edge_index(self) -> np.ndarray:
        """Build edge connectivity matrix"""
        
        edges = []
        
        for gate_a, gate_b, _ in self.channels:
            # Convert to 0-indexed
            idx_a = gate_a - 1
            idx_b = gate_b - 1
            
            # Add bidirectional edges
            edges.append([idx_a, idx_b])
            edges.append([idx_b, idx_a])
        
        edge_index = np.array(edges, dtype=np.int64).T  # [2, num_edges]
        
        return edge_index
    
    def _build_awareness_masks(self) -> Dict[str, np.ndarray]:
        """Build boolean masks for awareness gate groupings"""
        
        masks = {}
        
        for awareness_type, gate_set in self.awareness_gates.items():
            mask = np.zeros(64, dtype=bool)
            for gate in gate_set:
                mask[gate - 1] = True
            masks[awareness_type] = mask
        
        # Heart gates mask
        heart_mask = np.zeros(64, dtype=bool)
        for gate in HEART_GATES:
            heart_mask[gate - 1] = True
        masks['heart'] = heart_mask
        
        return masks
    
    def _get_gate_center(self, gate_num: int) -> str:
        """Get which center a gate belongs to"""
        for center, gates in self.center_gates.items():
            if gate_num in gates:
                return center
        return "unknown"
    
    def _encode_center(self, center: str) -> List[float]:
        """One-hot encode center"""
        centers = ["head", "ajna", "throat", "g", "heart", "sacral", "spleen", "solar_plexus", "root"]
        encoding = [0.0] * len(centers)
        if center in centers:
            encoding[centers.index(center)] = 1.0
        return encoding
    
    def to_torch(self, graph_data: Dict) -> Dict:
        """Convert numpy arrays to PyTorch tensors"""
        return {
            "node_features": torch.from_numpy(graph_data["node_features"]),
            "edge_index": torch.from_numpy(graph_data["edge_index"]),
            "awareness_masks": {
                k: torch.from_numpy(v) for k, v in graph_data["awareness_masks"].items()
            },
            "chart": graph_data["chart"]
        }

# Example usage
if __name__ == "__main__":
    # Example chart
    chart = HDChart(
        type="Generator",
        strategy="To Respond",
        authority="Sacral",
        profile="4/6",
        defined_centers=["sacral", "throat", "g"],
        undefined_centers=["head", "ajna", "heart", "spleen", "solar_plexus", "root"],
        gates={
            20: {"line": 3, "activation": "personality", "center": "throat"},
            34: {"line": 5, "activation": "personality", "center": "sacral"},
            57: {"line": 1, "activation": "design", "center": "spleen"},
            10: {"line": 2, "activation": "design", "center": "g"}
        },
        channels=[
            {"gate_a": 20, "gate_b": 34, "name": "Charisma"},
            {"gate_a": 10, "gate_b": 57, "name": "Survival"}
        ]
    )
    
    builder = GraphBuilder()
    graph = builder.build_graph(chart)
    
    print("Graph Builder Test")
    print(f"Node features shape: {graph['node_features'].shape}")
    print(f"Edge index shape: {graph['edge_index'].shape}")
    print(f"Awareness masks: {list(graph['awareness_masks'].keys())}")
    print(f"Spleen gates active: {graph['awareness_masks']['spleen'].sum()}")
