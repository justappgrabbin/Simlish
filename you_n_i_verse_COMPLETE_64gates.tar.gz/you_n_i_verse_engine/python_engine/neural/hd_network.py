"""
HD Network - Graph Neural Network with FiLM Modulation

PyTorch implementation of the 64-node HD consciousness graph:
- Message passing over channel structure
- Sun-based FiLM (Feature-wise Linear Modulation)
- Awareness pooling (Spleen/Ajna/Solar)
- Heart/Mind readouts
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple

class GraphConvLayer(nn.Module):
    """Simple graph convolution layer"""
    
    def __init__(self, in_dim: int, out_dim: int):
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim)
        
    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Node features [num_nodes, in_dim]
            edge_index: Edge connectivity [2, num_edges]
        Returns:
            Updated node features [num_nodes, out_dim]
        """
        # Simple message passing: aggregate neighbor features
        row, col = edge_index
        
        # Aggregate messages from neighbors
        aggregated = torch.zeros_like(x)
        for i in range(x.size(0)):
            neighbors = col[row == i]
            if len(neighbors) > 0:
                aggregated[i] = x[neighbors].mean(dim=0)
        
        # Combine with self features
        combined = x + aggregated
        
        # Transform
        return F.relu(self.linear(combined))

class SunFiLM(nn.Module):
    """Feature-wise Linear Modulation by Sun position"""
    
    def __init__(self, feature_dim: int, sun_dim: int = 70):
        super().__init__()
        # Sun encoding: gate (64) + line (6) one-hots
        self.mlp = nn.Sequential(
            nn.Linear(sun_dim, 64),
            nn.ReLU(),
            nn.Linear(64, feature_dim * 2)
        )
        
    def forward(self, x: torch.Tensor, sun_encoding: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Features to modulate [batch/nodes, feature_dim]
            sun_encoding: Sun gate + line encoding [sun_dim]
        Returns:
            Modulated features [batch/nodes, feature_dim]
        """
        # Generate gamma (scale) and beta (shift)
        params = self.mlp(sun_encoding)
        gamma, beta = params.chunk(2, dim=-1)
        
        # Apply FiLM: y = gamma * x + beta
        return gamma * x + beta

class GlobalAttentionPooling(nn.Module):
    """Attention-based pooling over node subset"""
    
    def __init__(self, feature_dim: int):
        super().__init__()
        self.attention_weights = nn.Linear(feature_dim, 1)
        
    def forward(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Node features [num_nodes, feature_dim]
            mask: Boolean mask for subset [num_nodes]
        Returns:
            Pooled representation [feature_dim]
        """
        # Apply mask
        masked_features = x[mask]  # [num_masked, feature_dim]
        
        if masked_features.size(0) == 0:
            return torch.zeros(x.size(1), device=x.device)
        
        # Compute attention weights
        attn_logits = self.attention_weights(masked_features)  # [num_masked, 1]
        attn_weights = F.softmax(attn_logits, dim=0)
        
        # Weighted sum
        pooled = (masked_features * attn_weights).sum(dim=0)
        
        return pooled

class HDNetwork(nn.Module):
    """
    Complete HD Graph Neural Network
    
    Architecture:
    1. Graph convolution layers (message passing)
    2. Sun FiLM modulation
    3. Per-gate readout (64 scores)
    4. Awareness pooling (Spleen/Ajna/Solar)
    5. Heart/Mind readouts (Sun-modulated)
    """
    
    def __init__(self, 
                 input_dim: int = 19,    # From graph_builder features
                 hidden_dim: int = 64,
                 num_layers: int = 3,
                 sun_dim: int = 70):
        super().__init__()
        
        self.hidden_dim = hidden_dim
        
        # Graph convolution layers
        self.conv_layers = nn.ModuleList()
        self.conv_layers.append(GraphConvLayer(input_dim, hidden_dim))
        for _ in range(num_layers - 1):
            self.conv_layers.append(GraphConvLayer(hidden_dim, hidden_dim))
        
        # Sun FiLM modulation
        self.sun_film = SunFiLM(hidden_dim, sun_dim)
        
        # Per-gate readout
        self.gate_readout = nn.Linear(hidden_dim, 1)
        
        # Awareness pooling
        self.pool_spleen = GlobalAttentionPooling(hidden_dim)
        self.pool_ajna = GlobalAttentionPooling(hidden_dim)
        self.pool_solar = GlobalAttentionPooling(hidden_dim)
        self.pool_heart = GlobalAttentionPooling(hidden_dim)
        
        # Mind readout (uses ajna pool, modulated by Sun)
        self.mind_projection = nn.Linear(hidden_dim, hidden_dim)
        
    def forward(self, 
                node_features: torch.Tensor,
                edge_index: torch.Tensor,
                awareness_masks: Dict[str, torch.Tensor],
                sun_encoding: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Args:
            node_features: [64, input_dim]
            edge_index: [2, num_edges]
            awareness_masks: Dict of boolean masks
            sun_encoding: [sun_dim] Sun gate + line one-hot
        
        Returns:
            Dictionary with:
                - codon_scores: [64] activation per gate
                - spleen_awareness: [hidden_dim]
                - ajna_awareness: [hidden_dim]
                - solar_awareness: [hidden_dim]
                - heart: [hidden_dim] (Sun-modulated)
                - mind: [hidden_dim] (Sun-modulated)
        """
        
        # 1. Message passing through graph
        h = node_features
        for conv in self.conv_layers:
            h = conv(h, edge_index)
        
        # 2. Sun FiLM modulation
        h_modulated = self.sun_film(h, sun_encoding)
        
        # 3. Per-gate activation scores
        codon_scores = self.gate_readout(h_modulated).squeeze(-1)  # [64]
        
        # 4. Awareness pooling (WITHOUT Sun modulation)
        spleen_awareness = self.pool_spleen(h, awareness_masks['spleen'])
        ajna_awareness = self.pool_ajna(h, awareness_masks['ajna'])
        solar_awareness = self.pool_solar(h, awareness_masks['solar'])
        
        # 5. Heart readout (WITH Sun modulation)
        heart_pool = self.pool_heart(h_modulated, awareness_masks['heart'])
        
        # 6. Mind readout (Ajna pool + Sun modulation)
        mind_base = self.mind_projection(ajna_awareness)
        mind_modulated = self.sun_film(mind_base.unsqueeze(0), sun_encoding).squeeze(0)
        
        return {
            "codon_scores": codon_scores,
            "spleen_awareness": spleen_awareness,
            "ajna_awareness": ajna_awareness,
            "solar_awareness": solar_awareness,
            "heart": heart_pool,
            "mind": mind_modulated
        }
    
    def encode_sun_position(self, sun_gate: int, sun_line: int) -> torch.Tensor:
        """
        Encode Sun position as one-hot vectors
        
        Args:
            sun_gate: Gate number (1-64)
            sun_line: Line number (1-6)
        
        Returns:
            Concatenated one-hot encoding [70] (64 + 6)
        """
        gate_onehot = torch.zeros(64)
        gate_onehot[sun_gate - 1] = 1.0
        
        line_onehot = torch.zeros(6)
        line_onehot[sun_line - 1] = 1.0
        
        return torch.cat([gate_onehot, line_onehot])

# Example usage
if __name__ == "__main__":
    print("HD Network Test")
    
    # Create model
    model = HDNetwork(input_dim=19, hidden_dim=64)
    
    # Dummy inputs
    node_features = torch.randn(64, 19)
    edge_index = torch.randint(0, 64, (2, 100))
    
    awareness_masks = {
        'spleen': torch.zeros(64, dtype=torch.bool),
        'ajna': torch.zeros(64, dtype=torch.bool),
        'solar_plexus': torch.zeros(64, dtype=torch.bool),
        'heart': torch.zeros(64, dtype=torch.bool)
    }
    
    # Set some gates active
    awareness_masks['spleen'][[56, 43, 49]] = True  # Gates 57, 44, 50
    awareness_masks['ajna'][[46, 23, 3]] = True     # Gates 47, 24, 4
    
    # Sun position (Gate 25, Line 3)
    sun_encoding = model.encode_sun_position(25, 3)
    
    # Forward pass
    output = model(node_features, edge_index, awareness_masks, sun_encoding)
    
    print(f"\nCodon scores shape: {output['codon_scores'].shape}")
    print(f"Spleen awareness shape: {output['spleen_awareness'].shape}")
    print(f"Heart readout shape: {output['heart'].shape}")
    print(f"Mind readout shape: {output['mind'].shape}")
    
    print(f"\nTop 5 activated gates: {torch.argsort(output['codon_scores'], descending=True)[:5] + 1}")
    
    print("\n✅ HD Network test passed")
