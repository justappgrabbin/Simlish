"""
YOU-N-I-VERSE Neural Network Module

Graph Neural Network implementation for HD consciousness computation:
- Graph building from HD charts
- Message passing over channel structure
- Sun FiLM modulation
- Awareness pooling
- Training system
"""

from .graph_builder import GraphBuilder, HDChart, CHANNELS, AWARENESS_GATES
from .hd_network import HDNetwork, SunFiLM, GlobalAttentionPooling
from .awareness_pooler import AwarenessPooler, AwarenessAnalysis, AwarenessVisualizer
from .training import HDTrainer, HDLoss, TrainingConfig

__version__ = "0.2.0"

__all__ = [
    # Graph building
    "GraphBuilder",
    "HDChart",
    "CHANNELS",
    "AWARENESS_GATES",
    
    # Neural network
    "HDNetwork",
    "SunFiLM",
    "GlobalAttentionPooling",
    
    # Awareness
    "AwarenessPooler",
    "AwarenessAnalysis",
    "AwarenessVisualizer",
    
    # Training
    "HDTrainer",
    "HDLoss",
    "TrainingConfig"
]
