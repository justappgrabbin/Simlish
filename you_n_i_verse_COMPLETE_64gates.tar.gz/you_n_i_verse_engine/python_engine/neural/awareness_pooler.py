"""
Awareness Pooler - Advanced Analysis of Consciousness Fields

Provides detailed analysis of the three awareness streams:
- Splenic Awareness (intuitive/survival)
- Ajna Awareness (mental/conceptual)
- Solar Plexus Awareness (emotional/wave)

Plus Heart/Mind integration analysis.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Tuple
from dataclasses import dataclass

@dataclass
class AwarenessAnalysis:
    """Complete awareness analysis result"""
    spleen_score: float
    ajna_score: float
    solar_score: float
    heart_score: float
    mind_score: float
    dominant_awareness: str
    awareness_balance: float
    coherence: float

class AwarenessPooler:
    """Advanced awareness analysis and interpretation"""
    
    AWARENESS_DESCRIPTIONS = {
        "spleen": {
            "name": "Splenic Awareness",
            "nature": "Intuitive, In-the-Moment, Survival",
            "gates": [57, 44, 50, 32, 28, 18],
            "qualities": ["instinct", "clarity", "fear-recognition", "spontaneity"]
        },
        "ajna": {
            "name": "Ajna Awareness",
            "nature": "Mental, Conceptual, Pattern Recognition",
            "gates": [47, 24, 4, 17, 11, 43],
            "qualities": ["analysis", "logic", "interpretation", "meaning-making"]
        },
        "solar_plexus": {
            "name": "Solar Plexus Awareness",
            "nature": "Emotional, Wave-Based, Depth",
            "gates": [55, 49, 37, 22, 30, 36, 6],
            "qualities": ["feeling", "passion", "empathy", "intensity"]
        }
    }
    
    def __init__(self):
        self.awareness_types = ["spleen", "ajna", "solar_plexus"]
        
    def analyze_awareness(self, 
                         network_output: Dict[str, torch.Tensor],
                         gate_scores: torch.Tensor) -> AwarenessAnalysis:
        """
        Comprehensive awareness analysis
        
        Args:
            network_output: Output from HDNetwork
            gate_scores: Per-gate activation scores [64]
        
        Returns:
            AwarenessAnalysis with detailed metrics
        """
        
        # Extract awareness vectors
        spleen = network_output['spleen_awareness'].detach().cpu().numpy()
        ajna = network_output['ajna_awareness'].detach().cpu().numpy()
        solar = network_output['solar_awareness'].detach().cpu().numpy()
        heart = network_output['heart'].detach().cpu().numpy()
        mind = network_output['mind'].detach().cpu().numpy()
        
        # Calculate scores (magnitude of each awareness)
        spleen_score = float(np.linalg.norm(spleen))
        ajna_score = float(np.linalg.norm(ajna))
        solar_score = float(np.linalg.norm(solar))
        heart_score = float(np.linalg.norm(heart))
        mind_score = float(np.linalg.norm(mind))
        
        # Determine dominant awareness
        scores = {
            "spleen": spleen_score,
            "ajna": ajna_score,
            "solar_plexus": solar_score
        }
        dominant = max(scores.keys(), key=lambda k: scores[k])
        
        # Calculate awareness balance (how evenly distributed)
        score_values = list(scores.values())
        mean_score = np.mean(score_values)
        balance = 1.0 - (np.std(score_values) / (mean_score + 1e-8))
        
        # Calculate coherence (alignment between awareness types)
        coherence = self._calculate_awareness_coherence(spleen, ajna, solar)
        
        return AwarenessAnalysis(
            spleen_score=spleen_score,
            ajna_score=ajna_score,
            solar_score=solar_score,
            heart_score=heart_score,
            mind_score=mind_score,
            dominant_awareness=dominant,
            awareness_balance=float(balance),
            coherence=float(coherence)
        )
    
    def _calculate_awareness_coherence(self, 
                                      spleen: np.ndarray,
                                      ajna: np.ndarray,
                                      solar: np.ndarray) -> float:
        """Calculate how aligned the three awareness types are"""
        
        # Normalize
        spleen_norm = spleen / (np.linalg.norm(spleen) + 1e-8)
        ajna_norm = ajna / (np.linalg.norm(ajna) + 1e-8)
        solar_norm = solar / (np.linalg.norm(solar) + 1e-8)
        
        # Pairwise correlations
        spleen_ajna = np.dot(spleen_norm, ajna_norm)
        spleen_solar = np.dot(spleen_norm, solar_norm)
        ajna_solar = np.dot(ajna_norm, solar_norm)
        
        # Average coherence
        return (spleen_ajna + spleen_solar + ajna_solar) / 3.0
    
    def interpret_awareness(self, analysis: AwarenessAnalysis) -> str:
        """Generate natural language interpretation"""
        
        dominant_info = self.AWARENESS_DESCRIPTIONS[analysis.dominant_awareness]
        
        interpretation = f"""
Consciousness Awareness Analysis:

Primary Mode: {dominant_info['name']}
Nature: {dominant_info['nature']}

Awareness Scores:
  Splenic (Intuitive):  {analysis.spleen_score:.3f}
  Ajna (Mental):        {analysis.ajna_score:.3f}
  Solar Plexus (Emotional): {analysis.solar_score:.3f}
  
Integration:
  Heart Expression:     {analysis.heart_score:.3f}
  Mind Coherence:       {analysis.mind_score:.3f}

Balance: {analysis.awareness_balance:.3f}
(1.0 = perfectly balanced, 0.0 = heavily skewed)

Coherence: {analysis.coherence:.3f}
(How aligned the awareness types are)

Dominant Qualities: {', '.join(dominant_info['qualities'])}
"""
        
        return interpretation
    
    def get_gate_awareness_breakdown(self, 
                                    gate_scores: torch.Tensor,
                                    awareness_masks: Dict[str, torch.Tensor]) -> Dict:
        """Show which gates are driving each awareness type"""
        
        gate_scores_np = gate_scores.detach().cpu().numpy()
        breakdown = {}
        
        for awareness_type, mask in awareness_masks.items():
            if awareness_type in ['spleen', 'ajna', 'solar_plexus']:
                mask_np = mask.cpu().numpy()
                relevant_gates = np.where(mask_np)[0] + 1  # Convert to 1-indexed
                relevant_scores = gate_scores_np[mask_np]
                
                # Sort by score
                sorted_indices = np.argsort(relevant_scores)[::-1]
                
                breakdown[awareness_type] = {
                    'gates': relevant_gates[sorted_indices].tolist(),
                    'scores': relevant_scores[sorted_indices].tolist()
                }
        
        return breakdown

class AwarenessVisualizer:
    """Visualize awareness patterns (text-based for now)"""
    
    @staticmethod
    def create_awareness_bar(score: float, width: int = 20) -> str:
        """Create ASCII bar chart"""
        filled = int(score * width)
        bar = "█" * filled + "░" * (width - filled)
        return f"[{bar}] {score:.3f}"
    
    @staticmethod
    def visualize_analysis(analysis: AwarenessAnalysis) -> str:
        """Create text visualization of awareness analysis"""
        
        viz = f"""
╔════════════════════════════════════════╗
║     AWARENESS FIELD VISUALIZATION      ║
╚════════════════════════════════════════╝

Splenic    {AwarenessVisualizer.create_awareness_bar(analysis.spleen_score)}
Ajna       {AwarenessVisualizer.create_awareness_bar(analysis.ajna_score)}
Solar      {AwarenessVisualizer.create_awareness_bar(analysis.solar_score)}

Heart      {AwarenessVisualizer.create_awareness_bar(analysis.heart_score)}
Mind       {AwarenessVisualizer.create_awareness_bar(analysis.mind_score)}

Balance:   {AwarenessVisualizer.create_awareness_bar(analysis.awareness_balance)}
Coherence: {AwarenessVisualizer.create_awareness_bar(analysis.coherence)}

Dominant Mode: {analysis.dominant_awareness.upper()}
"""
        return viz

# Example usage
if __name__ == "__main__":
    print("Awareness Pooler Test\n")
    
    # Simulate network output
    network_output = {
        'spleen_awareness': torch.randn(64),
        'ajna_awareness': torch.randn(64),
        'solar_awareness': torch.randn(64),
        'heart': torch.randn(64),
        'mind': torch.randn(64)
    }
    
    gate_scores = torch.rand(64)
    
    # Analyze
    pooler = AwarenessPooler()
    analysis = pooler.analyze_awareness(network_output, gate_scores)
    
    # Interpret
    interpretation = pooler.interpret_awareness(analysis)
    print(interpretation)
    
    # Visualize
    viz = AwarenessVisualizer.visualize_analysis(analysis)
    print(viz)
    
    print("\n✅ Awareness Pooler test passed")
