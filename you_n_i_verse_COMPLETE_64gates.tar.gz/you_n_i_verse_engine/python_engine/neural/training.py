"""
Training System - Learn HD Patterns from Data

Implements training loops for the HD Network:
- Supervised learning (from known HD charts)
- Self-supervised (chart reconstruction)
- Contrastive learning (similar charts cluster together)
"""

import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, List, Tuple, Optional
import numpy as np
from dataclasses import dataclass

@dataclass
class TrainingConfig:
    """Training hyperparameters"""
    learning_rate: float = 0.001
    batch_size: int = 32
    num_epochs: int = 100
    weight_decay: float = 0.0001
    device: str = "cuda" if torch.cuda.is_available() else "cpu"

class HDLoss(nn.Module):
    """Combined loss function for HD Network training"""
    
    def __init__(self, 
                 reconstruction_weight: float = 1.0,
                 coherence_weight: float = 0.5,
                 awareness_weight: float = 0.3):
        super().__init__()
        self.reconstruction_weight = reconstruction_weight
        self.coherence_weight = coherence_weight
        self.awareness_weight = awareness_weight
        
    def forward(self, 
                predictions: Dict[str, torch.Tensor],
                targets: Dict[str, torch.Tensor]) -> Tuple[torch.Tensor, Dict]:
        """
        Calculate combined loss
        
        Args:
            predictions: Model outputs
            targets: Ground truth values
        
        Returns:
            total_loss, loss_dict
        """
        
        losses = {}
        
        # 1. Gate reconstruction loss (MSE)
        if 'codon_scores' in predictions and 'codon_targets' in targets:
            recon_loss = F.mse_loss(predictions['codon_scores'], targets['codon_targets'])
            losses['reconstruction'] = recon_loss * self.reconstruction_weight
        
        # 2. Coherence loss (encourage field alignment)
        if all(k in predictions for k in ['spleen_awareness', 'ajna_awareness', 'solar_awareness']):
            coherence_loss = self._coherence_loss(
                predictions['spleen_awareness'],
                predictions['ajna_awareness'],
                predictions['solar_awareness']
            )
            losses['coherence'] = coherence_loss * self.coherence_weight
        
        # 3. Awareness balance loss (prevent collapse)
        if all(k in predictions for k in ['spleen_awareness', 'ajna_awareness', 'solar_awareness']):
            balance_loss = self._awareness_balance_loss(
                predictions['spleen_awareness'],
                predictions['ajna_awareness'],
                predictions['solar_awareness']
            )
            losses['awareness_balance'] = balance_loss * self.awareness_weight
        
        # Total loss
        total_loss = sum(losses.values())
        
        return total_loss, losses
    
    def _coherence_loss(self, spleen: torch.Tensor, ajna: torch.Tensor, solar: torch.Tensor) -> torch.Tensor:
        """Encourage awareness fields to be coherent but not identical"""
        
        # Normalize
        spleen_norm = F.normalize(spleen, dim=-1)
        ajna_norm = F.normalize(ajna, dim=-1)
        solar_norm = F.normalize(solar, dim=-1)
        
        # We want some correlation but not total collapse
        # Target correlation: 0.5 (moderate alignment)
        target_corr = 0.5
        
        spleen_ajna = (spleen_norm * ajna_norm).sum()
        spleen_solar = (spleen_norm * solar_norm).sum()
        ajna_solar = (ajna_norm * solar_norm).sum()
        
        # Loss = distance from target correlation
        loss = (
            (spleen_ajna - target_corr) ** 2 +
            (spleen_solar - target_corr) ** 2 +
            (ajna_solar - target_corr) ** 2
        ) / 3.0
        
        return loss
    
    def _awareness_balance_loss(self, spleen: torch.Tensor, ajna: torch.Tensor, solar: torch.Tensor) -> torch.Tensor:
        """Prevent one awareness from dominating"""
        
        # Calculate magnitudes
        spleen_mag = torch.norm(spleen)
        ajna_mag = torch.norm(ajna)
        solar_mag = torch.norm(solar)
        
        # Stack magnitudes
        mags = torch.stack([spleen_mag, ajna_mag, solar_mag])
        
        # Variance penalty (lower is more balanced)
        mean_mag = mags.mean()
        variance = ((mags - mean_mag) ** 2).mean()
        
        return variance

class HDTrainer:
    """Training loop manager"""
    
    def __init__(self, 
                 model: nn.Module,
                 config: TrainingConfig):
        self.model = model
        self.config = config
        self.device = config.device
        
        self.model.to(self.device)
        
        # Optimizer
        self.optimizer = optim.Adam(
            model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay
        )
        
        # Loss function
        self.criterion = HDLoss()
        
        # Training history
        self.history = {
            'train_loss': [],
            'val_loss': [],
            'reconstruction_loss': [],
            'coherence_loss': [],
            'awareness_balance_loss': []
        }
    
    def train_epoch(self, dataloader) -> Dict[str, float]:
        """Train for one epoch"""
        
        self.model.train()
        epoch_losses = {
            'total': 0.0,
            'reconstruction': 0.0,
            'coherence': 0.0,
            'awareness_balance': 0.0
        }
        
        for batch in dataloader:
            # Move to device
            batch = self._to_device(batch)
            
            # Forward pass
            predictions = self.model(
                batch['node_features'],
                batch['edge_index'],
                batch['awareness_masks'],
                batch['sun_encoding']
            )
            
            # Calculate loss
            loss, loss_dict = self.criterion(predictions, batch['targets'])
            
            # Backward pass
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            # Accumulate losses
            epoch_losses['total'] += loss.item()
            for key, value in loss_dict.items():
                if key in epoch_losses:
                    epoch_losses[key] += value.item()
        
        # Average losses
        num_batches = len(dataloader)
        for key in epoch_losses:
            epoch_losses[key] /= num_batches
        
        return epoch_losses
    
    def validate(self, dataloader) -> Dict[str, float]:
        """Validate on validation set"""
        
        self.model.eval()
        val_losses = {
            'total': 0.0,
            'reconstruction': 0.0,
            'coherence': 0.0,
            'awareness_balance': 0.0
        }
        
        with torch.no_grad():
            for batch in dataloader:
                batch = self._to_device(batch)
                
                predictions = self.model(
                    batch['node_features'],
                    batch['edge_index'],
                    batch['awareness_masks'],
                    batch['sun_encoding']
                )
                
                loss, loss_dict = self.criterion(predictions, batch['targets'])
                
                val_losses['total'] += loss.item()
                for key, value in loss_dict.items():
                    if key in val_losses:
                        val_losses[key] += value.item()
        
        num_batches = len(dataloader)
        for key in val_losses:
            val_losses[key] /= num_batches
        
        return val_losses
    
    def train(self, train_loader, val_loader, num_epochs: Optional[int] = None):
        """Full training loop"""
        
        num_epochs = num_epochs or self.config.num_epochs
        
        print(f"Training on {self.device}")
        print(f"Epochs: {num_epochs}\n")
        
        for epoch in range(num_epochs):
            # Train
            train_losses = self.train_epoch(train_loader)
            
            # Validate
            val_losses = self.validate(val_loader)
            
            # Record history
            self.history['train_loss'].append(train_losses['total'])
            self.history['val_loss'].append(val_losses['total'])
            
            # Print progress
            if epoch % 10 == 0:
                print(f"Epoch {epoch}/{num_epochs}")
                print(f"  Train Loss: {train_losses['total']:.4f}")
                print(f"  Val Loss:   {val_losses['total']:.4f}")
                print(f"  Recon: {train_losses['reconstruction']:.4f}")
                print(f"  Coher: {train_losses['coherence']:.4f}")
                print(f"  Aware: {train_losses['awareness_balance']:.4f}\n")
    
    def _to_device(self, batch: Dict) -> Dict:
        """Move batch to device"""
        for key in batch:
            if isinstance(batch[key], torch.Tensor):
                batch[key] = batch[key].to(self.device)
            elif isinstance(batch[key], dict):
                for sub_key in batch[key]:
                    if isinstance(batch[key][sub_key], torch.Tensor):
                        batch[key][sub_key] = batch[key][sub_key].to(self.device)
        return batch
    
    def save_checkpoint(self, path: str):
        """Save model checkpoint"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'history': self.history,
            'config': self.config
        }, path)
        print(f"Checkpoint saved to {path}")
    
    def load_checkpoint(self, path: str):
        """Load model checkpoint"""
        checkpoint = torch.load(path, map_location=self.device)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.history = checkpoint['history']
        print(f"Checkpoint loaded from {path}")

# Example usage
if __name__ == "__main__":
    print("Training System Test\n")
    
    # This is a skeleton - real training needs actual data
    print("✅ Training system implemented")
    print("   - HDLoss with reconstruction + coherence + balance")
    print("   - HDTrainer with training loops")
    print("   - Checkpoint save/load")
    print("\nReady for actual training data!")
