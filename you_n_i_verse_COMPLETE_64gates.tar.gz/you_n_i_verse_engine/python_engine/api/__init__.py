"""
YOU-N-I-VERSE API Module

REST API for consciousness computation:
- FastAPI server
- Godot bridge protocol
- WebSocket support (future)
"""

__version__ = "0.2.0"
