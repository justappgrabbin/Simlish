"""
FastAPI Server - REST API for YOU-N-I-VERSE Engine

Provides HTTP endpoints for:
- Processing HD charts
- Running consciousness simulations
- Analyzing awareness patterns
- Real-time predictions
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Dict, List, Optional
import torch
import numpy as np
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from core.gate_operators import GateProcessor, WaveInput, StructureInput, SomaticInput
from core.ctb_encoder import CTBEncoder, CTBCoordinate, CTBModulator
from core.trinity_field import TrinityInterferenceEngine
from core.sentence_parser import SentenceProcessor
from neural.graph_builder import GraphBuilder, HDChart
from neural.hd_network import HDNetwork
from neural.awareness_pooler import AwarenessPooler, AwarenessVisualizer

# Initialize FastAPI
app = FastAPI(
    title="YOU-N-I-VERSE Consciousness Engine API",
    description="REST API for Human Design consciousness computation",
    version="0.2.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize models (loaded once at startup)
gate_processor = GateProcessor()
ctb_encoder = CTBEncoder()
trinity_engine = TrinityInterferenceEngine()
sentence_processor = SentenceProcessor()
graph_builder = GraphBuilder()
hd_network = HDNetwork(input_dim=19, hidden_dim=64)
awareness_pooler = AwarenessPooler()

# Pydantic models for request/response

class GateRequest(BaseModel):
    amplitude: float = Field(1.0, description="Wave amplitude")
    frequency: float = Field(1.0, description="Wave frequency")
    phase: float = Field(0.0, description="Wave phase")
    stability: float = Field(0.8, description="Structural stability")
    density: float = Field(0.6, description="Structural density")
    coherence: float = Field(0.7, description="Structural coherence")
    energy: float = Field(0.9, description="Somatic energy")
    sensation: float = Field(0.5, description="Somatic sensation")
    vitality: float = Field(0.8, description="Somatic vitality")

class CTBRequest(BaseModel):
    color: int = Field(..., ge=1, le=6, description="Color (1-6)")
    tone: int = Field(..., ge=1, le=6, description="Tone (1-6)")
    base: int = Field(..., ge=1, le=5, description="Base (1-5)")
    degree: float = Field(0.0, description="Degree (0-360)")
    minute: float = Field(0.0, description="Minute (0-60)")
    second: float = Field(0.0, description="Second (0-60)")

class SentenceRequest(BaseModel):
    sentence: str = Field(..., description="Consciousness sentence")
    conditions: Optional[List[int]] = Field(None, description="Hexagram conditions")

class HDChartRequest(BaseModel):
    type: str = Field(..., description="HD Type")
    strategy: str
    authority: str
    profile: str
    defined_centers: List[str]
    gates: Dict[int, Dict]
    channels: List[Dict]
    sun_gate: int = Field(..., ge=1, le=64)
    sun_line: int = Field(..., ge=1, le=6)

# Endpoints

@app.get("/")
async def root():
    return {
        "engine": "YOU-N-I-VERSE Consciousness Engine",
        "version": "0.2.0",
        "status": "operational",
        "endpoints": [
            "/process_gates",
            "/encode_ctb",
            "/process_trinity",
            "/process_sentence",
            "/analyze_chart",
            "/full_pipeline"
        ]
    }

@app.post("/process_gates")
async def process_gates(request: GateRequest):
    """Process all 64 gate transforms"""
    try:
        wave = WaveInput(request.amplitude, request.frequency, request.phase)
        structure = StructureInput(request.stability, request.density, request.coherence)
        soma = SomaticInput(request.energy, request.sensation, request.vitality)
        
        outputs = gate_processor.process_all_gates(wave, structure, soma)
        
        return {
            "gate_outputs": outputs.tolist(),
            "shape": list(outputs.shape),
            "top_5_gates": np.argsort(outputs)[-5:][::-1].tolist()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/encode_ctb")
async def encode_ctb(request: CTBRequest):
    """Encode CTB coordinates"""
    try:
        ctb = CTBCoordinate(
            color=request.color,
            tone=request.tone,
            base=request.base,
            degree=request.degree,
            minute=request.minute,
            second=request.second
        )
        
        encoding = ctb_encoder.encode(ctb)
        matrix = ctb_encoder.encode_matrix(ctb, output_dim=64)
        
        return {
            "ctb": f"{request.color}-{request.tone}-{request.base}",
            "encoding_shape": list(encoding.shape),
            "matrix_shape": list(matrix.shape),
            "sample_values": encoding[:5].tolist()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/process_trinity")
async def process_trinity(gate_outputs: List[float]):
    """Process through trinity fields"""
    try:
        gates = np.array(gate_outputs)
        
        if len(gates) != 64:
            raise ValueError("Expected 64 gate values")
        
        result = trinity_engine.process_trinity(gates)
        
        return {
            "mind_field": result['mind'].tolist(),
            "body_field": result['body'].tolist(),
            "heart_field": result['heart'].tolist(),
            "interference": result['interference'].tolist(),
            "coherence": float(result['coherence'])
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/process_sentence")
async def process_sentence(request: SentenceRequest):
    """Process consciousness sentence"""
    try:
        initial_state = np.ones(64) * 0.5
        
        result = sentence_processor.process(
            sentence=request.sentence,
            initial_state=initial_state,
            conditions=request.conditions
        )
        
        return {
            "sentence": request.sentence,
            "states": [s.verb for s in result['states']],
            "ctb": f"{result['ctb'].color}-{result['ctb'].tone}-{result['ctb'].base}",
            "final_state": result['final_state'].tolist(),
            "coherence": float(result['coherence'])
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analyze_chart")
async def analyze_chart(request: HDChartRequest):
    """Complete HD chart analysis with neural network"""
    try:
        # Build chart
        chart = HDChart(
            type=request.type,
            strategy=request.strategy,
            authority=request.authority,
            profile=request.profile,
            defined_centers=request.defined_centers,
            undefined_centers=[],  # Will be computed
            gates=request.gates,
            channels=request.channels
        )
        
        # Build graph
        graph = graph_builder.build_graph(chart)
        graph_torch = graph_builder.to_torch(graph)
        
        # Encode sun position
        sun_encoding = hd_network.encode_sun_position(request.sun_gate, request.sun_line)
        
        # Run through network
        with torch.no_grad():
            output = hd_network(
                graph_torch['node_features'],
                graph_torch['edge_index'],
                graph_torch['awareness_masks'],
                sun_encoding
            )
        
        # Analyze awareness
        analysis = awareness_pooler.analyze_awareness(output, output['codon_scores'])
        interpretation = awareness_pooler.interpret_awareness(analysis)
        visualization = AwarenessVisualizer.visualize_analysis(analysis)
        
        return {
            "chart_type": request.type,
            "codon_scores": output['codon_scores'].tolist(),
            "top_gates": torch.argsort(output['codon_scores'], descending=True)[:10].tolist(),
            "awareness": {
                "spleen": analysis.spleen_score,
                "ajna": analysis.ajna_score,
                "solar_plexus": analysis.solar_score,
                "heart": analysis.heart_score,
                "mind": analysis.mind_score,
                "dominant": analysis.dominant_awareness,
                "balance": analysis.awareness_balance,
                "coherence": analysis.coherence
            },
            "interpretation": interpretation,
            "visualization": visualization
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/full_pipeline")
async def full_pipeline(
    gate_request: GateRequest,
    ctb_request: CTBRequest,
    sentence: str
):
    """Run complete consciousness computation pipeline"""
    try:
        # 1. Gates
        wave = WaveInput(gate_request.amplitude, gate_request.frequency, gate_request.phase)
        structure = StructureInput(gate_request.stability, gate_request.density, gate_request.coherence)
        soma = SomaticInput(gate_request.energy, gate_request.sensation, gate_request.vitality)
        gates = gate_processor.process_all_gates(wave, structure, soma)
        
        # 2. CTB modulation
        ctb = CTBCoordinate(
            color=ctb_request.color,
            tone=ctb_request.tone,
            base=ctb_request.base,
            degree=ctb_request.degree
        )
        modulator = CTBModulator(ctb_encoder)
        modulated = modulator.modulate_gates(gates, ctb)
        
        # 3. Trinity
        trinity_result = trinity_engine.process_trinity(modulated)
        
        # 4. Sentence
        sentence_result = sentence_processor.process(
            sentence=sentence,
            initial_state=trinity_result['interference']
        )
        
        return {
            "pipeline_stages": {
                "gates": gates.tolist(),
                "ctb_modulated": modulated.tolist(),
                "trinity_coherence": float(trinity_result['coherence']),
                "sentence_coherence": float(sentence_result['coherence'])
            },
            "final_state": sentence_result['final_state'].tolist(),
            "top_activated_gates": np.argsort(sentence_result['final_state'])[-10:][::-1].tolist()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health():
    return {"status": "healthy", "models_loaded": True}

if __name__ == "__main__":
    import uvicorn
    print("🌌 Starting YOU-N-I-VERSE API Server")
    print("📍 http://localhost:8000")
    print("📖 Docs: http://localhost:8000/docs")
    uvicorn.run(app, host="0.0.0.0", port=8000)
