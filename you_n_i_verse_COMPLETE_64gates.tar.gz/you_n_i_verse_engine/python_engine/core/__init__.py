"""
YOU-N-I-VERSE Consciousness Engine - Core Module

This module contains the fundamental mathematical components:
- Gate operators (64 consciousness transform functions)
- CTB encoder (Color-Tone-Base coordinate system)
- Trinity field (Mind-Body-Heart interference)
- Sentence parser (state machine processor)
"""

from .gate_operators import (
    GateOperator,
    GateProcessor,
    GateOperatorFactory,
    WaveInput,
    StructureInput,
    SomaticInput
)

from .ctb_encoder import (
    CTBEncoder,
    CTBCoordinate,
    CTBModulator
)

from .trinity_field import (
    TrinityInterferenceEngine,
    TrinityField
)

from .sentence_parser import (
    SentenceParser,
    SentenceProcessor,
    SentenceState,
    TransitionOperator
)

__version__ = "0.1.0"
__author__ = "Celestial"

__all__ = [
    # Gate operators
    "GateOperator",
    "GateProcessor",
    "GateOperatorFactory",
    "WaveInput",
    "StructureInput",
    "SomaticInput",
    
    # CTB system
    "CTBEncoder",
    "CTBCoordinate",
    "CTBModulator",
    
    # Trinity fields
    "TrinityInterferenceEngine",
    "TrinityField",
    
    # Sentence processing
    "SentenceParser",
    "SentenceProcessor",
    "SentenceState",
    "TransitionOperator"
]
