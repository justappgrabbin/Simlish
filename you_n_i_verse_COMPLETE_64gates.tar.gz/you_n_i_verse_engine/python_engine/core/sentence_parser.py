"""
Sentence Parser & State Machine

Processes consciousness sentences into mathematical state progressions.

Sentence structure: Verb₁. Verb₂. Verb₃. Gate-state.
Each period (.) = Transitioner operator T
Formula: G = T³(O) where O = initial state, G = gate state

Example: "Observe. Prepare. Understand. The gate awaits."
"""

import re
import numpy as np
from typing import List, Dict, Tuple
from dataclasses import dataclass
from .ctb_encoder import CTBCoordinate, CTBEncoder

@dataclass
class SentenceState:
    """State in sentence progression"""
    verb: str
    state_index: int
    activation: np.ndarray

class SentenceParser:
    """Parse sentences into mathematical state sequences"""
    
    OPERATORS = {
        '.': 'transitioner',
        ',': 'breath',
        ';': 'fork',
        ':': 'portal',
        '°': 'collapse',
        '•': 'singularity',
        '′': 'pulse',
        '″': 'flicker',
    }
    
    def __init__(self):
        self.ctb_encoder = CTBEncoder()
        
    def parse(self, sentence: str) -> List[SentenceState]:
        """Parse sentence into state sequence"""
        parts = sentence.split('.')
        states = []
        
        for idx, part in enumerate(parts):
            part = part.strip()
            if part:
                words = part.split()
                verb = words[0].lower() if words else "unknown"
                
                states.append(SentenceState(
                    verb=verb,
                    state_index=idx,
                    activation=np.zeros(64)
                ))
        
        return states
    
    def extract_ctb(self, text: str) -> CTBCoordinate:
        """Extract CTB coordinates from text"""
        pattern = r'(\d+)[-–](\d+)[-–](\d+)'
        match = re.search(pattern, text)
        
        if match:
            color = int(match.group(1))
            tone = int(match.group(2))
            base = int(match.group(3))
            return CTBCoordinate(color, tone, base)
        
        return CTBCoordinate(color=4, tone=5, base=3)

class TransitionOperator:
    """T operator: transitions between states"""
    
    def __init__(self, ctb_encoder: CTBEncoder):
        self.ctb_encoder = ctb_encoder
        
    def apply(self, current_state: np.ndarray, 
             ctb: CTBCoordinate, 
             condition: int) -> np.ndarray:
        """Apply transition: s_{k+1} = T_{CTB,c}(s_k)"""
        
        ctb_weights = self.ctb_encoder.encode_matrix(ctb, output_dim=64)
        modulated = current_state * ctb_weights
        transformed = self._apply_condition(modulated, condition)
        transformed = transformed / (np.linalg.norm(transformed) + 1e-8)
        
        return transformed
    
    def _apply_condition(self, state: np.ndarray, condition: int) -> np.ndarray:
        """Apply hexagram condition transform"""
        rotation_angle = (condition / 64.0) * 2 * np.pi
        phase_shift = np.sin(rotation_angle)
        transformed = state * (1.0 + phase_shift * 0.3)
        return transformed

class SentenceProcessor:
    """Process complete sentences through state machine"""
    
    def __init__(self):
        self.parser = SentenceParser()
        self.transition = TransitionOperator(self.parser.ctb_encoder)
        
    def process(self, sentence: str, initial_state: np.ndarray,
               conditions: List[int] = None) -> Dict:
        """Process sentence through state machine"""
        
        states = self.parser.parse(sentence)
        ctb = self.parser.extract_ctb(sentence)
        
        if conditions is None:
            conditions = [64, 64, 64]
        
        current = initial_state
        trajectory = [current.copy()]
        
        for idx in range(len(states) - 1):
            condition = conditions[idx] if idx < len(conditions) else 64
            current = self.transition.apply(current, ctb, condition)
            trajectory.append(current.copy())
        
        final_state = trajectory[-1]
        
        return {
            "states": states,
            "ctb": ctb,
            "conditions": conditions,
            "trajectory": trajectory,
            "final_state": final_state,
            "coherence": self._calculate_trajectory_coherence(trajectory)
        }
    
    def _calculate_trajectory_coherence(self, trajectory: List[np.ndarray]) -> float:
        """Calculate state progression coherence"""
        if len(trajectory) < 2:
            return 1.0
        
        coherences = []
        for i in range(len(trajectory) - 1):
            s1 = trajectory[i] / (np.linalg.norm(trajectory[i]) + 1e-8)
            s2 = trajectory[i + 1] / (np.linalg.norm(trajectory[i + 1]) + 1e-8)
            corr = np.dot(s1, s2)
            coherences.append(corr)
        
        return float(np.mean(coherences))

if __name__ == "__main__":
    sentence = "Observe. Prepare. Understand. The gate awaits."
    initial_state = np.ones(64) * 0.5
    
    processor = SentenceProcessor()
    result = processor.process(sentence, initial_state, conditions=[64, 64, 64])
    
    print("Sentence Processor Test")
    print(f"Sentence: {sentence}")
    print(f"States: {[s.verb for s in result['states']]}")
    print(f"CTB: {result['ctb'].color}-{result['ctb'].tone}-{result['ctb'].base}")
    print(f"Final state (first 5): {result['final_state'][:5]}")
    print(f"Coherence: {result['coherence']:.3f}")
