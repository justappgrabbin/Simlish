"""
CTB Encoder - Color-Tone-Base Coordinate System

Encodes Human Design Color-Tone-Base coordinates into weight matrices
for modulating consciousness transforms.

Color (1-6): Fear, Hope, Desire, Need, Guilt, Innocence
Tone (1-6): Security, Insecurity, Action, Meditation, Touch, Taste  
Base (1-5): Prevention, Power, Mutation, Action, Survival
"""

import numpy as np
from typing import Tuple
from dataclasses import dataclass

@dataclass
class CTBCoordinate:
    """Color-Tone-Base coordinate"""
    color: int  # 1-6
    tone: int   # 1-6
    base: int   # 1-5
    degree: float = 0.0
    minute: float = 0.0
    second: float = 0.0

class CTBEncoder:
    """Encodes Color-Tone-Base coordinates into weight matrices"""
    
    COLOR_NAMES = {
        1: "Fear", 2: "Hope", 3: "Desire",
        4: "Need", 5: "Guilt", 6: "Innocence"
    }
    
    TONE_NAMES = {
        1: "Security", 2: "Insecurity", 3: "Action",
        4: "Meditation", 5: "Touch", 6: "Taste"
    }
    
    BASE_NAMES = {
        1: "Prevention", 2: "Power", 3: "Mutation",
        4: "Action", 5: "Survival"
    }
    
    def __init__(self, hidden_dim: int = 64):
        self.hidden_dim = hidden_dim
        np.random.seed(42)  # Reproducible
        self.color_embedding = np.random.randn(6, hidden_dim) * 0.1
        self.tone_embedding = np.random.randn(6, hidden_dim) * 0.1
        self.base_embedding = np.random.randn(5, hidden_dim) * 0.1
        
    def encode(self, ctb: CTBCoordinate) -> np.ndarray:
        """Convert CTB coordinate to weight vector"""
        color_vec = self.color_embedding[ctb.color - 1]
        tone_vec = self.tone_embedding[ctb.tone - 1]
        base_vec = self.base_embedding[ctb.base - 1]
        
        ctb_vector = color_vec * tone_vec * base_vec
        rotation = self._apply_degree_transform(ctb.degree)
        harmonics = self._calculate_harmonics(ctb.minute, ctb.second)
        
        return ctb_vector * rotation * harmonics
    
    def _apply_degree_transform(self, degree: float) -> float:
        """Convert degree to rotational modulation"""
        radians = np.deg2rad(degree)
        rotation_factor = (np.sin(radians) + 1.0) / 2.0
        return 0.5 + rotation_factor * 0.5
    
    def _calculate_harmonics(self, minute: float, second: float) -> float:
        """Calculate subharmonic modulation"""
        minute_harmonic = np.sin(minute / 60.0 * 2 * np.pi)
        second_harmonic = np.sin(second / 60.0 * 2 * np.pi) * 0.1
        return 1.0 + minute_harmonic * 0.3 + second_harmonic
    
    def encode_matrix(self, ctb: CTBCoordinate, output_dim: int = 64) -> np.ndarray:
        """Generate full weight matrix from CTB"""
        ctb_vector = self.encode(ctb)
        projection = np.random.randn(output_dim, self.hidden_dim) * 0.1
        weight_matrix = projection @ ctb_vector.reshape(-1, 1)
        return weight_matrix.flatten()

class CTBModulator:
    """Apply CTB modulation to gate outputs"""
    
    def __init__(self, encoder: CTBEncoder):
        self.encoder = encoder
        
    def modulate_gates(self, gate_outputs: np.ndarray, ctb: CTBCoordinate) -> np.ndarray:
        """Apply CTB modulation to all 64 gate outputs"""
        ctb_weights = self.encoder.encode_matrix(ctb, output_dim=64)
        return gate_outputs * ctb_weights
    
    def film_modulation(self, features: np.ndarray, ctb: CTBCoordinate) -> np.ndarray:
        """FiLM-style modulation"""
        ctb_vector = self.encoder.encode(ctb)
        gamma = np.tanh(ctb_vector[:len(features)])
        beta = ctb_vector[:len(features)] * 0.1
        return gamma * features + beta

if __name__ == "__main__":
    ctb = CTBCoordinate(color=4, tone=5, base=3, degree=25.5, minute=59.0, second=32.0)
    encoder = CTBEncoder()
    weights = encoder.encode(ctb)
    print(f"CTB Encoder Test")
    print(f"CTB: {ctb.color}-{ctb.tone}-{ctb.base}")
    print(f"Encoding shape: {weights.shape}")
    print(f"Sample values: {weights[:5]}")
