"""
YOU-N-I-VERSE Engine - Complete Examples

Demonstrates all Phase 1 functionality:
1. Gate Operators
2. CTB Encoding
3. Trinity Field Interference
4. Sentence Processing
5. Full Pipeline Integration
"""

import numpy as np
import sys
sys.path.append('python_engine')

from core.gate_operators import (
    GateProcessor, WaveInput, StructureInput, SomaticInput, GateOperatorFactory
)
from core.ctb_encoder import CTBEncoder, CTBCoordinate, CTBModulator
from core.trinity_field import TrinityInterferenceEngine
from core.sentence_parser import SentenceProcessor

def example_1_gate_operators():
    """Example 1: Process all 64 gate transforms"""
    print("\n" + "="*60)
    print("EXAMPLE 1: GATE OPERATORS")
    print("="*60)
    
    # Create inputs
    wave = WaveInput(amplitude=1.0, frequency=1.0, phase=0.0)
    structure = StructureInput(stability=0.8, density=0.6, coherence=0.7)
    soma = SomaticInput(energy=0.9, sensation=0.5, vitality=0.8)
    
    # Process all gates
    processor = GateProcessor()
    outputs = processor.process_all_gates(wave, structure, soma)
    
    print(f"\nProcessed all 64 gates")
    print(f"Output shape: {outputs.shape}")
    print(f"\nSpecific gate outputs:")
    print(f"  Gate 1 (Creative):  {outputs[0]:.4f}")
    print(f"  Gate 34 (Power):    {outputs[33]:.4f}")
    print(f"  Gate 57 (Intuition): {outputs[56]:.4f}")
    print(f"  Gate 64 (Confusion): {outputs[63]:.4f}")
    
    print(f"\nImplemented gates: {GateOperatorFactory.get_implemented_gates()}")
    print(f"Generic gates: 56 (remaining)")

def example_2_ctb_encoding():
    """Example 2: CTB coordinate encoding"""
    print("\n" + "="*60)
    print("EXAMPLE 2: CTB ENCODING")
    print("="*60)
    
    # Create CTB coordinate (4-5-3 from your documents)
    ctb = CTBCoordinate(
        color=4,     # Need
        tone=5,      # Touch
        base=3,      # Mutation
        degree=25.5,
        minute=59.0,
        second=32.0
    )
    
    # Encode
    encoder = CTBEncoder()
    weights = encoder.encode(ctb)
    matrix = encoder.encode_matrix(ctb, output_dim=64)
    
    print(f"\nCTB Coordinate: {ctb.color}-{ctb.tone}-{ctb.base}")
    print(f"  Color: {encoder.COLOR_NAMES[ctb.color]}")
    print(f"  Tone: {encoder.TONE_NAMES[ctb.tone]}")
    print(f"  Base: {encoder.BASE_NAMES[ctb.base]}")
    print(f"  Position: {ctb.degree}° {ctb.minute}' {ctb.second}\"")
    
    print(f"\nEncoding results:")
    print(f"  Vector shape: {weights.shape}")
    print(f"  Matrix shape: {matrix.shape}")
    print(f"  Sample values: {weights[:5]}")

def example_3_trinity_fields():
    """Example 3: Trinity field interference"""
    print("\n" + "="*60)
    print("EXAMPLE 3: TRINITY FIELD INTERFERENCE")
    print("="*60)
    
    # Simulate gate outputs
    np.random.seed(42)
    gate_outputs = np.random.rand(64)
    
    # Process through trinity
    engine = TrinityInterferenceEngine()
    result = engine.process_trinity(gate_outputs)
    
    print(f"\nProcessed through Mind-Body-Heart fields:")
    print(f"\nMind Field (semantic/conceptual):")
    print(f"  First 5 values: {result['mind'][:5]}")
    print(f"  Emphasizes: Head, Ajna gates")
    
    print(f"\nBody Field (structural/gravitational):")
    print(f"  First 5 values: {result['body'][:5]}")
    print(f"  Emphasizes: Motor centers")
    
    print(f"\nHeart Field (resonance/emotional):")
    print(f"  First 5 values: {result['heart'][:5]}")
    print(f"  Emphasizes: Solar Plexus, Heart gates")
    
    print(f"\nInterference Pattern:")
    print(f"  First 5 values: {result['interference'][:5]}")
    print(f"  Field Coherence: {result['coherence']:.3f}")

def example_4_sentence_processing():
    """Example 4: Sentence state machine"""
    print("\n" + "="*60)
    print("EXAMPLE 4: SENTENCE PROCESSING")
    print("="*60)
    
    # The example sentence from your documents
    sentence = "Observe. Prepare. Understand. The gate awaits."
    
    # Initial state (baseline activation)
    initial_state = np.ones(64) * 0.5
    
    # Process sentence
    processor = SentenceProcessor()
    result = processor.process(
        sentence=sentence,
        initial_state=initial_state,
        conditions=[64, 64, 64]  # Gate 64: Before Completion
    )
    
    print(f"\nSentence: {sentence}")
    print(f"\nParsed states: {[s.verb for s in result['states']]}")
    print(f"State count: {len(result['states'])}")
    
    print(f"\nCTB Parameters:")
    print(f"  {result['ctb'].color}-{result['ctb'].tone}-{result['ctb'].base}")
    
    print(f"\nConditions (hexagrams): {result['conditions']}")
    
    print(f"\nTrajectory:")
    for i, state in enumerate(result['trajectory']):
        print(f"  State {i}: mean={state.mean():.4f}, max={state.max():.4f}")
    
    print(f"\nFinal State (first 10 gates):")
    print(f"  {result['final_state'][:10]}")
    
    print(f"\nTrajectory Coherence: {result['coherence']:.3f}")

def example_5_full_pipeline():
    """Example 5: Complete integrated pipeline"""
    print("\n" + "="*60)
    print("EXAMPLE 5: FULL INTEGRATED PIPELINE")
    print("="*60)
    
    print("\n🌌 Processing consciousness through complete engine...")
    
    # Step 1: Gate Operators
    print("\n1️⃣  GATE OPERATORS")
    wave = WaveInput(amplitude=1.0, frequency=1.0, phase=0.0)
    structure = StructureInput(stability=0.8, density=0.6, coherence=0.7)
    soma = SomaticInput(energy=0.9, sensation=0.5, vitality=0.8)
    
    processor = GateProcessor()
    gate_outputs = processor.process_all_gates(wave, structure, soma)
    print(f"   ✓ 64 gates processed")
    
    # Step 2: CTB Modulation
    print("\n2️⃣  CTB MODULATION")
    ctb = CTBCoordinate(color=4, tone=5, base=3, degree=25.5)
    encoder = CTBEncoder()
    modulator = CTBModulator(encoder)
    
    modulated_gates = modulator.modulate_gates(gate_outputs, ctb)
    print(f"   ✓ Gates modulated by CTB 4-5-3")
    
    # Step 3: Trinity Interference
    print("\n3️⃣  TRINITY INTERFERENCE")
    trinity = TrinityInterferenceEngine()
    trinity_result = trinity.process_trinity(modulated_gates)
    print(f"   ✓ Mind-Body-Heart fields calculated")
    print(f"   ✓ Coherence: {trinity_result['coherence']:.3f}")
    
    # Step 4: Sentence Processing
    print("\n4️⃣  SENTENCE STATE MACHINE")
    sentence = "Observe. Prepare. Understand. The gate awaits."
    sentence_proc = SentenceProcessor()
    
    sentence_result = sentence_proc.process(
        sentence=sentence,
        initial_state=trinity_result['interference'],
        conditions=[64, 64, 64]
    )
    print(f"   ✓ Sentence processed through states")
    print(f"   ✓ Trajectory coherence: {sentence_result['coherence']:.3f}")
    
    # Final Results
    print("\n🎯 FINAL CONSCIOUSNESS STATE:")
    final = sentence_result['final_state']
    print(f"   Dimension: {final.shape}")
    print(f"   Mean activation: {final.mean():.4f}")
    print(f"   Max activation: {final.max():.4f}")
    print(f"   Top 5 activated gates: {np.argsort(final)[-5:][::-1] + 1}")
    
    print("\n✅ Complete pipeline executed successfully!")

if __name__ == "__main__":
    print("\n" + "🌌"*30)
    print("YOU-N-I-VERSE CONSCIOUSNESS ENGINE - PHASE 1 EXAMPLES")
    print("🌌"*30)
    
    example_1_gate_operators()
    example_2_ctb_encoding()
    example_3_trinity_fields()
    example_4_sentence_processing()
    example_5_full_pipeline()
    
    print("\n" + "="*60)
    print("ALL EXAMPLES COMPLETED")
    print("="*60 + "\n")
