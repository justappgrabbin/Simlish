# 🌌 YOU-N-I-VERSE CONSCIOUSNESS ENGINE

A complete implementation of the Human Design-based consciousness computation system combining:
- Mathematical gate operators (64 transform functions)
- Color-Tone-Base (CTB) encoding system
- Trinity field interference (Mind-Body-Heart)
- Sentence-based state machines
- Graph Neural Networks with FiLM modulation
- Godot game engine integration

## 🏗️ Project Structure

```
you_n_i_verse_engine/
├── python_engine/           # Core Python computation engine
│   ├── core/               # Mathematical foundations
│   │   ├── gate_operators.py     # 64 HD gate transforms
│   │   ├── ctb_encoder.py        # Color-Tone-Base system
│   │   ├── trinity_field.py      # Mind-Body-Heart interference
│   │   ├── sentence_parser.py    # State machine processor
│   │   └── constants.py          # HD mappings
│   ├── neural/             # Graph Neural Network
│   │   ├── graph_builder.py      # Chart → graph converter
│   │   ├── hd_network.py         # GNN with FiLM
│   │   └── awareness_pooler.py   # Spleen/Ajna/Solar
│   ├── api/                # API interfaces
│   │   ├── engine_api.py         # FastAPI server
│   │   └── godot_bridge.py       # Godot communication
│   └── data/               # Configuration files
│       ├── gates.yaml
│       ├── channels.yaml
│       └── awareness_masks.yaml
├── godot_integration/      # Godot GDScript files
│   ├── python_bridge.gd
│   ├── neural_predictor.gd
│   └── consciousness_engine.gd
└── tests/                  # Unit tests

```

## 📦 Phase 1 Completion Status

✅ **COMPLETED:**
- Gate Operators (8 implemented, 56 generic placeholders)
- CTB Encoder (complete)
- Trinity Field Interference (complete)
- Sentence Parser & State Machine (complete)
- Project structure
- Documentation

🚧 **NEXT PHASE:**
- Graph Neural Network (PyTorch)
- Awareness Pooling System
- FastAPI Bridge
- Godot Integration
- Training loops

## 🚀 Installation

### Prerequisites
```bash
python 3.10+
pip
```

### Setup
```bash
# Clone or download this repository
cd you_n_i_verse_engine

# Install Python dependencies
pip install -r python_engine/requirements.txt

# Test core modules
python -m pytest tests/
```

## 🧪 Quick Start

### Example 1: Gate Operators
```python
from python_engine.core.gate_operators import (
    GateProcessor, WaveInput, StructureInput, SomaticInput
)

# Create inputs
wave = WaveInput(amplitude=1.0, frequency=1.0, phase=0.0)
structure = StructureInput(stability=0.8, density=0.6, coherence=0.7)
soma = SomaticInput(energy=0.9, sensation=0.5, vitality=0.8)

# Process all 64 gates
processor = GateProcessor()
outputs = processor.process_all_gates(wave, structure, soma)

print(f"Gate outputs shape: {outputs.shape}")  # (64,)
print(f"Gate 34 (Power): {outputs[33]}")
```

### Example 2: CTB Encoding
```python
from python_engine.core.ctb_encoder import CTBEncoder, CTBCoordinate

# Create CTB coordinate (4-5-3 example)
ctb = CTBCoordinate(
    color=4,  # Need
    tone=5,   # Touch
    base=3,   # Mutation
    degree=25.5,
    minute=59.0,
    second=32.0
)

# Encode to weight vector
encoder = CTBEncoder()
weights = encoder.encode(ctb)

print(f"CTB encoding shape: {weights.shape}")
```

### Example 3: Trinity Field Interference
```python
from python_engine.core.trinity_field import TrinityInterferenceEngine
import numpy as np

# Simulate gate outputs
gate_outputs = np.random.rand(64)

# Process through trinity fields
engine = TrinityInterferenceEngine()
result = engine.process_trinity(gate_outputs)

print(f"Mind field: {result['mind'][:5]}")
print(f"Body field: {result['body'][:5]}")
print(f"Heart field: {result['heart'][:5]}")
print(f"Interference pattern: {result['interference'][:5]}")
print(f"Coherence: {result['coherence']:.3f}")
```

### Example 4: Sentence Processing
```python
from python_engine.core.sentence_parser import SentenceProcessor
import numpy as np

# Parse a consciousness sentence
sentence = "Observe. Prepare. Understand. The gate awaits."

# Initial state (all gates at baseline)
initial_state = np.ones(64) * 0.5

# Process sentence
processor = SentenceProcessor()
result = processor.process(
    sentence=sentence,
    initial_state=initial_state,
    conditions=[64, 64, 64]  # Gate 64: Before Completion
)

print(f"States parsed: {[s.verb for s in result['states']]}")
print(f"CTB: {result['ctb'].color}-{result['ctb'].tone}-{result['ctb'].base}")
print(f"Final state (first 5 gates): {result['final_state'][:5]}")
print(f"Trajectory coherence: {result['coherence']:.3f}")
```

## 🧬 System Architecture

### The Mathematical Flow
```
SENTENCE INPUT
    ↓
STATE PARSING ("Observe. Prepare. Understand. Gate.")
    ↓
CTB EXTRACTION (Color-Tone-Base parameters)
    ↓
GATE OPERATORS (64 transform functions)
    ↓
TRINITY INTERFERENCE (Mind ∘ Body ∘ Heart)
    ↓
STATE TRANSITIONS (T operator applied)
    ↓
FINAL CONSCIOUSNESS STATE
```

### The Trinity Fields
- **Mind Field**: Semantic/conceptual interpretation (emphasizes Head/Ajna)
- **Body Field**: Structural/gravitational stability (emphasizes Motors)
- **Heart Field**: Resonance/emotional modulation (emphasizes Solar Plexus)

**Interference Formula:**
```
MindField = interpret(BodyField ∘ HeartField ∘ GateTransform)
```

### CTB System
Color-Tone-Base coordinates parameterize all transformations:
- **Color** (1-6): Primary modulation (Fear, Hope, Desire, Need, Guilt, Innocence)
- **Tone** (1-6): Secondary modulation (Security, Insecurity, Action, Meditation, Touch, Taste)
- **Base** (1-5): Tertiary modulation (Prevention, Power, Mutation, Action, Survival)
- **Degree/Minute/Second**: Fine-grained rotational and harmonic adjustments

## 📚 Theoretical Foundation

This engine implements the consciousness computation model described in:
1. **"Complete Sentence System Breakdown"** - State machine mathematics
2. **"Neural Network Architecture"** - GNN with FiLM modulation
3. **Ra Uru Hu's Human Design System** - 64 gates, 9 centers, channels

### Key Concepts
- **Gates**: 64 I Ching hexagrams mapped to transform functions
- **Centers**: 9 consciousness hubs (Head, Ajna, Throat, G, Heart, Sacral, Spleen, Solar Plexus, Root)
- **Channels**: Connections between gates creating defined pathways
- **Trinity**: Mind-Body-Heart interference creating consciousness field
- **Sentences**: Mathematical operators creating state progressions

## 🎯 Phase 1 Deliverables

This package includes the **core mathematical engine**:

1. ✅ **Gate Operators** - Transform functions for consciousness processing
2. ✅ **CTB Encoder** - Coordinate-to-weight conversion system
3. ✅ **Trinity Engine** - Three-field interference calculator
4. ✅ **Sentence Parser** - State machine for consciousness sentences
5. ✅ **Documentation** - Complete API reference and examples

## 🔜 Coming in Phase 2

- **Graph Neural Network**: PyTorch GNN with message passing
- **FiLM Modulation**: Sun-based dynamic modulation
- **Awareness Pooling**: Spleen/Ajna/Solar Plexus readout heads
- **Training System**: Learn from HD chart data
- **FastAPI Server**: REST API for remote computation
- **Godot Bridge**: Real-time integration with game engine

## 🧪 Testing

```bash
# Run all tests
python -m pytest tests/ -v

# Test specific module
python -m pytest tests/test_gate_operators.py
python -m pytest tests/test_ctb_encoder.py
python -m pytest tests/test_trinity_field.py
python -m pytest tests/test_sentence_parser.py
```

## 📖 Documentation

Detailed API documentation is available in each module:
- `python_engine/core/gate_operators.py` - Gate transform API
- `python_engine/core/ctb_encoder.py` - CTB encoding API
- `python_engine/core/trinity_field.py` - Trinity field API
- `python_engine/core/sentence_parser.py` - Sentence processing API

## 🤝 Contributing

This is a foundational system. To extend:
1. Implement remaining 56 gate operators in `gate_operators.py`
2. Add domain-specific CTB embeddings in `ctb_encoder.py`
3. Customize trinity field weights in `trinity_field.py`
4. Create new sentence operators in `sentence_parser.py`

## 📄 License

[Your License Here]

## 🙏 Acknowledgments

Built on the theoretical work of:
- Ra Uru Hu (Human Design System)
- Richard Rudd (Gene Keys)
- Celestial (Trinity Model & Sentence Grammar)

---

**Status**: Phase 1 Complete ✅  
**Version**: 0.1.0  
**Last Updated**: December 2024
